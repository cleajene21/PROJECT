import 'package:flutter/foundation.dart' show kDebugMode;
import 'dart:developer' as developer;
import 'package:flutter/material.dart';
import '../services/auth_service.dart';
import '../services/firestore_service.dart';
import 'home_user.dart';
import 'home_admin.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _formKey = GlobalKey<FormState>();
  final _emailCtrl = TextEditingController();
  final _passwordCtrl = TextEditingController();
  bool _loading = false;

  Future<void> _signInWithGoogle() async {
    setState(() => _loading = true);
    try {
      final result = await AuthService().signInWithGoogle();
      if (!mounted) return;

      if (result == null) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Google sign-in canceled')),
        );
      } else {
        // StreamBuilder in main.dart will navigate to HomeScreen, but we'll navigate directly for immediacy
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Signed in as ${result.user?.displayName ?? ''}')),
        );
        if (kDebugMode) developer.log('[LoginScreen] signIn result user=${result.user?.uid}');

        final user = result.user!;
        // If email not verified, send to verification screen
        if (!user.emailVerified) {
          Navigator.of(context).pushReplacementNamed('/verify');
          return;
        }
        // Fetch role and navigate accordingly
        final role = await FirestoreService().getRole(user.uid);
        if (!mounted) return;
        if (role == 'admin') {
          Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const HomeAdmin()));
        } else {
          Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const HomeUser()));
        }
      }
    } catch (e, st) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Sign in failed: $e')),
        );
      }
      if (kDebugMode) developer.log('[LoginScreen] signIn failed: $e\n$st');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _signInWithEmail() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _loading = true);
    try {
      final result = await AuthService().signInWithEmail(email: _emailCtrl.text.trim(), password: _passwordCtrl.text);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Signed in as ${result.user?.email ?? ''}')));

      final user = result.user!;
      if (!user.emailVerified) {
        Navigator.of(context).pushReplacementNamed('/verify');
        return;
      }

      final role = await FirestoreService().getRole(user.uid);
      if (!mounted) return;
      if (role == 'admin') {
        Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const HomeAdmin()));
      } else {
        Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const HomeUser()));
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Sign in failed: $e')));
      if (kDebugMode) developer.log('[LoginScreen] email signIn failed: $e');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Sign In')),
      body: Center(
        child: _loading
            ? const CircularProgressIndicator()
            : Padding(
                padding: const EdgeInsets.all(24.0),
                child: Form(
                  key: _formKey,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Text(
                        'Welcome! Sign in to continue',
                        style: TextStyle(fontSize: 18),
                      ),
                      const SizedBox(height: 12),
                      TextFormField(controller: _emailCtrl, decoration: const InputDecoration(labelText: 'Email'), keyboardType: TextInputType.emailAddress, validator: (v) => v != null && v.contains('@') ? null : 'Enter a valid email'),
                      const SizedBox(height: 8),
                      TextFormField(controller: _passwordCtrl, decoration: const InputDecoration(labelText: 'Password'), obscureText: true, validator: (v) => v != null && v.isNotEmpty ? null : 'Enter your password'),
                      const SizedBox(height: 16),
                      _loading
                          ? const CircularProgressIndicator()
                          : Column(children: [
                              ElevatedButton(
                                onPressed: _signInWithEmail,
                                child: const Text('Sign in'),
                              ),
                              const SizedBox(height: 12),
                              ElevatedButton.icon(
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: Colors.white,
                                  foregroundColor: Colors.black,
                                  minimumSize: const Size(double.infinity, 48),
                                  side: const BorderSide(color: Colors.grey),
                                ),
                                icon: const Icon(Icons.login, size: 24),
                                label: const Text('Sign in with Google'),
                                onPressed: _signInWithGoogle,
                              ),
                            ]),
                      const SizedBox(height: 12),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          TextButton(onPressed: () => Navigator.of(context).pushNamed('/register'), child: const Text('Register')),
                          TextButton(onPressed: () => Navigator.of(context).pushNamed('/forgot'), child: const Text('Forgot password')),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
      ),
    );
  }
}
