import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../services/auth_service.dart';

class HomeAdmin extends StatelessWidget {
  const HomeAdmin({super.key});

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    return Scaffold(
      appBar: AppBar(title: const Text('Admin Home')),
      body: Center(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Text('Admin: ${user?.displayName ?? user?.email ?? 'Admin'}'),
          const SizedBox(height: 12),
          ElevatedButton(onPressed: () => AuthService().signOut(), child: const Text('Sign out')),
        ]),
      ),
    );
  }
}
