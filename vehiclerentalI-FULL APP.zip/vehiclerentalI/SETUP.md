# Vehicle Rental App - Complete Local Setup Guide

## Overview
This guide walks you through setting up the Vehicle Rental Flutter app with a local PHP/MySQL backend.

---

## Part 1: MySQL Database Setup

### Option A: Using XAMPP (Windows)
1. Download XAMPP from https://www.apachefriends.org/
2. Install and start XAMPP Control Panel
3. Click **Start** next to Apache and MySQL
4. Open phpMyAdmin: http://localhost/phpmyadmin
5. Click **New** (left sidebar) → create database `vehiclerental`
6. Click on the new database, go to **Import** tab
7. Choose `server/sql/schema.sql` from your project folder and click **Import**

### Option B: Command Line
```bash
# Windows (if MySQL is installed)
mysql -u root -p
```
Then in MySQL shell:
```sql
CREATE DATABASE vehiclerental CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE vehiclerental;
SOURCE C:\Users\cjmil\Downloads\vehiclerentalI\server\sql\schema.sql;
```

---

## Part 2: PHP API Setup

### 1. Copy PHP files to XAMPP
On Windows with XAMPP, copy the entire `server/php` folder to:
```
C:\xampp\htdocs\vehiclerental-api
```

### 2. Update config.php
Edit `C:\xampp\htdocs\vehiclerental-api\config.php`:
```php
return [
    'host' => '127.0.0.1',
    'port' => 3306,
    'dbname' => 'vehiclerental',
    'user' => 'root',           // Default XAMPP user
    'pass' => '',               // Default XAMPP has no password
];
```

### 3. Verify API is running
Open http://localhost/vehiclerental-api/health.php in your browser.
You should see:
```json
{
  "status": "ok",
  "message": "Vehicle Rental API is running",
  "timestamp": "2026-01-15T..."
}
```

---

## Part 3: Update Flutter App

### For Desktop/Web (localhost)
The app is already configured to use `http://localhost/vehiclerental-api/api`

### For Android Emulator
Edit `lib/services/firestore_service.dart`:
```dart
static const String API_BASE = 'http://10.0.2.2/vehiclerental-api/api';
```

### For Physical Android Device
1. Find your PC's local IP: Run `ipconfig` in PowerShell, look for IPv4 Address (e.g., `192.168.x.x`)
2. Edit `lib/services/firestore_service.dart`:
```dart
static const String API_BASE = 'http://YOUR_IP:80/vehiclerental-api/api';
```

---

## Part 4: Run the App

### Option A: Web (Chrome)
```bash
flutter run -d chrome
```

### Option B: Android Emulator
Make sure XAMPP is running and MySQL is accessible.
```bash
flutter run -d emulator-5554
```

### Option C: Physical Device
1. Connect device via USB and enable USB Debugging
2. Run: `flutter run`
3. Choose your device from the list

---

## Part 5: Test the Setup

1. **Open the Flutter app**
2. **Register** a new account (email/password)
3. **Check phpMyAdmin**: Users table should have new entry
4. **Add a vehicle** (if admin/owner)
5. **Check phpMyAdmin**: Vehicles table should update
6. **Try booking** a vehicle

---

## Troubleshooting

### "API error: Connection refused"
- Check XAMPP MySQL is running (green light in Control Panel)
- Check XAMPP Apache is running
- Verify `config.php` has correct credentials

### "Database connection failed"
- phpMyAdmin can connect? Try http://localhost/phpmyadmin
- If not, restart MySQL in XAMPP Control Panel
- Check MySQL username/password in `config.php`

### "404 Not Found" when calling API
- Is `vehiclerental-api` folder in `C:\xampp\htdocs`?
- Check URL in `lib/services/firestore_service.dart` matches folder name

### "Image loading fails"
- Images are downloaded from URLs; Firebase Storage may not be set up
- Use placeholder images for now

---

## For Production

1. Replace `localhost` with your domain/server IP in `API_BASE`
2. Enable HTTPS (use Let's Encrypt)
3. Add authentication/authorization to PHP API
4. Validate all inputs on server side
5. Use environment variables instead of hardcoded `API_BASE`
6. Set up proper database backups
7. Enable CORS headers if calling from different domain

---

## Quick Cheat Sheet

| What | Command | Where |
|------|---------|-------|
| Start MySQL & Apache | XAMPP Control Panel → Start | Windows |
| Access phpMyAdmin | http://localhost/phpmyadmin | Browser |
| Check API health | http://localhost/vehiclerental-api/health.php | Browser |
| Run Flutter app | `flutter run` | Terminal |
| View logs | `flutter run -v` | Terminal |

