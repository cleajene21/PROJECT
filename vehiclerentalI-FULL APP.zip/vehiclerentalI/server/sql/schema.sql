-- Vehicle Rental Database Schema
-- Import this into MySQL via phpMyAdmin or command line

CREATE DATABASE IF NOT EXISTS vehiclerental CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE vehiclerental;

-- Users Table
CREATE TABLE IF NOT EXISTS users (
  uid VARCHAR(128) NOT NULL PRIMARY KEY,
  email VARCHAR(255) UNIQUE,
  displayName VARCHAR(255),
  emailVerified TINYINT(1) DEFAULT 0,
  role VARCHAR(50) DEFAULT 'user' COMMENT 'user or admin',
  createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_email (email),
  INDEX idx_role (role)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Vehicles Table
CREATE TABLE IF NOT EXISTS vehicles (
  id INT AUTO_INCREMENT PRIMARY KEY,
  brand VARCHAR(255) NOT NULL,
  model VARCHAR(255) NOT NULL,
  type VARCHAR(100) COMMENT 'Sedan, SUV, etc',
  year VARCHAR(20),
  location VARCHAR(255),
  ownerId VARCHAR(128) NOT NULL,
  ownerName VARCHAR(255),
  ownerEmail VARCHAR(255),
  pricePerDay DOUBLE DEFAULT 0,
  isAvailable TINYINT(1) DEFAULT 1,
  imageUrls JSON COMMENT 'Array of image URLs',
  description TEXT,
  geoLat DOUBLE COMMENT 'Latitude for map',
  geoLng DOUBLE COMMENT 'Longitude for map',
  createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
  updatedAt DATETIME NULL ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_owner (ownerId),
  INDEX idx_available (isAvailable),
  FOREIGN KEY (ownerId) REFERENCES users(uid) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Bookings Table
CREATE TABLE IF NOT EXISTS bookings (
  id INT AUTO_INCREMENT PRIMARY KEY,
  vehicleId INT NOT NULL,
  vehicleBrand VARCHAR(255),
  vehicleModel VARCHAR(255),
  vehicleOwnerId VARCHAR(128) NOT NULL,
  vehicleOwnerName VARCHAR(255),
  renterId VARCHAR(128) NOT NULL,
  renterName VARCHAR(255),
  renterEmail VARCHAR(255),
  startDate DATETIME NOT NULL,
  endDate DATETIME NOT NULL,
  numberOfDays INT DEFAULT 0,
  totalPrice DOUBLE DEFAULT 0,
  status VARCHAR(50) DEFAULT 'pending' COMMENT 'pending, approved, declined, cancelled, completed',
  notes TEXT,
  createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
  updatedAt DATETIME NULL ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_vehicle (vehicleId),
  INDEX idx_renter (renterId),
  INDEX idx_owner (vehicleOwnerId),
  INDEX idx_status (status),
  INDEX idx_dates (startDate, endDate),
  FOREIGN KEY (vehicleId) REFERENCES vehicles(id) ON DELETE CASCADE,
  FOREIGN KEY (renterId) REFERENCES users(uid) ON DELETE CASCADE,
  FOREIGN KEY (vehicleOwnerId) REFERENCES users(uid) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Sample Data (Optional - remove if not needed)
-- INSERT INTO users (uid, email, displayName, role) VALUES 
-- ('owner1', 'owner@example.com', 'John Owner', 'admin'),
-- ('renter1', 'renter@example.com', 'Jane Renter', 'user');
