<?php
header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/config.php';

$config = require __DIR__ . '/config.php';
$dsn = sprintf('mysql:host=%s;port=%d;dbname=%s;charset=utf8mb4', $config['host'], $config['port'], $config['dbname']);

try {
    $pdo = new PDO($dsn, $config['user'], $config['pass'], [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
    
    // Check if vehicles table exists
    $stmt = $pdo->query("SHOW TABLES LIKE 'vehicles'");
    $tableExists = $stmt->fetch();
    
    if (!$tableExists) {
        echo json_encode(['error' => 'Vehicles table does not exist']);
        exit;
    }
    
    // Count vehicles
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM vehicles");
    $countResult = $stmt->fetch();
    $count = $countResult['count'];
    
    // Get first 5 vehicles
    $stmt = $pdo->query("SELECT * FROM vehicles LIMIT 5");
    $vehicles = $stmt->fetchAll();
    
    echo json_encode([
        'status' => 'success',
        'count' => $count,
        'vehicles' => $vehicles,
        'db_config' => [
            'host' => $config['host'],
            'dbname' => $config['dbname'],
            'port' => $config['port']
        ]
    ], JSON_PRETTY_PRINT);
    
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'error' => 'DB connection failed',
        'message' => $e->getMessage(),
        'db_config' => [
            'host' => $config['host'],
            'dbname' => $config['dbname'],
            'port' => $config['port']
        ]
    ], JSON_PRETTY_PRINT);
    exit;
}
?>
