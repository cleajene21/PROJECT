<?php
// Simple health check endpoint - no routing needed
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

echo json_encode([
    'status' => 'ok',
    'message' => 'Vehicle Rental API is running',
    'timestamp' => date(DATE_ATOM),
    'php_version' => phpversion()
], JSON_PRETTY_PRINT);
