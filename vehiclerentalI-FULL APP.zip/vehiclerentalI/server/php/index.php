<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once __DIR__ . '/db.php';

$method = $_SERVER['REQUEST_METHOD'];
$uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
// Extract path after /vehiclerental-api/
$basePath = '/vehiclerental-api/';
$path = strpos($uri, $basePath) !== false ? substr($uri, strlen($basePath)) : $uri;
$parts = array_values(array_filter(explode('/', $path)));

// Expecting /api/... or just api/...
if (count($parts) < 2 || ($parts[0] !== 'api' && $parts[1] !== 'api')) {
    // Check if this is the root - just return a basic message
    if (empty($parts) || count($parts) == 0) {
        http_response_code(200);
        echo json_encode(['message' => 'Vehicle Rental API']);
        exit;
    }
    http_response_code(404);
    echo json_encode(['error' => 'Not found']);
    exit;
}

// Find where 'api' is and shift accordingly
if ($parts[0] === 'api') {
    array_shift($parts);
} else {
    array_shift($parts);
    array_shift($parts);
}

$resource = $parts[0] ?? null;
$id = $parts[1] ?? null;

// Utility helpers
function json_post() {
    $raw = file_get_contents('php://input');
    return $raw ? json_decode($raw, true) : [];
}

// ROUTES
try {
    if ($resource === 'users') {
        if ($method === 'POST') {
            // create user if not exists. expects { uid, email, displayName, emailVerified }
            $data = json_post();
            $uid = $data['uid'] ?? null;
            if (!$uid) { http_response_code(400); echo json_encode(['error'=>'missing uid']); exit; }
            $stmt = $pdo->prepare('SELECT uid FROM users WHERE uid = ?');
            $stmt->execute([$uid]);
            if ($stmt->fetch()) { http_response_code(200); echo json_encode(['ok'=>true]); exit; }
            $stmt = $pdo->prepare('INSERT INTO users (uid, email, displayName, emailVerified, role) VALUES (?, ?, ?, ?, ?)');
            $stmt->execute([$uid, $data['email'] ?? '', $data['displayName'] ?? '', !empty($data['emailVerified']) ? 1 : 0, 'user']);
            http_response_code(201);
            echo json_encode(['ok'=>true]);
            exit;
        }

        if ($id && isset($parts[2]) && $parts[2] === 'role') {
            // /api/users/{uid}/role
            if ($method === 'GET') {
                $stmt = $pdo->prepare('SELECT role FROM users WHERE uid = ?');
                $stmt->execute([$id]);
                $row = $stmt->fetch();
                if (!$row) { http_response_code(404); echo json_encode(['role'=>'user']); exit; }
                echo json_encode(['role'=>$row['role']]); exit;
            } elseif ($method === 'PUT') {
                $data = json_post();
                $role = $data['role'] ?? 'user';
                $stmt = $pdo->prepare('UPDATE users SET role = ? WHERE uid = ?');
                $stmt->execute([$role, $id]);
                echo json_encode(['ok'=>true]); exit;
            }
        }
    }

    if ($resource === 'vehicles') {
        if ($method === 'GET' && !$id) {
            $stmt = $pdo->query('SELECT * FROM vehicles');
            $rows = $stmt->fetchAll();
            // Cast numeric fields to proper types
            $rows = array_map(function($row) {
                return [
                    'id' => (int)$row['id'],
                    'brand' => $row['brand'],
                    'model' => $row['model'],
                    'type' => $row['type'],
                    'year' => $row['year'],
                    'location' => $row['location'],
                    'ownerId' => $row['ownerId'],
                    'ownerName' => $row['ownerName'],
                    'ownerEmail' => $row['ownerEmail'],
                    'pricePerDay' => (float)$row['pricePerDay'],
                    'isAvailable' => (int)$row['isAvailable'],
                    'imageUrls' => json_decode($row['imageUrls'], true) ?? [],
                    'description' => $row['description'],
                    'geoLat' => $row['geoLat'] !== null ? (float)$row['geoLat'] : null,
                    'geoLng' => $row['geoLng'] !== null ? (float)$row['geoLng'] : null,
                    'createdAt' => $row['createdAt'],
                    'updatedAt' => $row['updatedAt'],
                ];
            }, $rows);
            echo json_encode($rows); exit;
        }
        if ($method === 'POST') {
            $data = json_post();
            $stmt = $pdo->prepare('INSERT INTO vehicles (brand, model, type, year, location, ownerId, ownerName, ownerEmail, pricePerDay, isAvailable, imageUrls, description, geoLat, geoLng) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
            $stmt->execute([
                $data['brand'] ?? '',
                $data['model'] ?? '',
                $data['type'] ?? '',
                $data['year'] ?? '',
                $data['location'] ?? '',
                $data['ownerId'] ?? '',
                $data['ownerName'] ?? '',
                $data['ownerEmail'] ?? '',
                $data['pricePerDay'] ?? 0,
                !empty($data['isAvailable']) ? 1 : 0,
                json_encode($data['imageUrls'] ?? []),
                $data['description'] ?? '',
                $data['geoLat'] ?? null,
                $data['geoLng'] ?? null,
            ]);
            $id = $pdo->lastInsertId();
            http_response_code(201);
            echo json_encode(['id'=>$id]); exit;
        }
        if ($id) {
            if ($method === 'GET') {
                $stmt = $pdo->prepare('SELECT * FROM vehicles WHERE id = ?');
                $stmt->execute([$id]);
                $row = $stmt->fetch();
                if (!$row) { http_response_code(404); echo json_encode(['error'=>'not found']); exit; }
                // Cast numeric fields to proper types
                $row = [
                    'id' => (int)$row['id'],
                    'brand' => $row['brand'],
                    'model' => $row['model'],
                    'type' => $row['type'],
                    'year' => $row['year'],
                    'location' => $row['location'],
                    'ownerId' => $row['ownerId'],
                    'ownerName' => $row['ownerName'],
                    'ownerEmail' => $row['ownerEmail'],
                    'pricePerDay' => (float)$row['pricePerDay'],
                    'isAvailable' => (int)$row['isAvailable'],
                    'imageUrls' => json_decode($row['imageUrls'], true) ?? [],
                    'description' => $row['description'],
                    'geoLat' => $row['geoLat'] !== null ? (float)$row['geoLat'] : null,
                    'geoLng' => $row['geoLng'] !== null ? (float)$row['geoLng'] : null,
                    'createdAt' => $row['createdAt'],
                    'updatedAt' => $row['updatedAt'],
                ];
                echo json_encode($row); exit;
            }
            if ($method === 'PUT') {
                $data = json_post();
                $stmt = $pdo->prepare('UPDATE vehicles SET brand=?, model=?, type=?, year=?, location=?, ownerId=?, ownerName=?, ownerEmail=?, pricePerDay=?, isAvailable=?, imageUrls=?, description=?, geoLat=?, geoLng=? WHERE id=?');
                $stmt->execute([
                    $data['brand'] ?? '',
                    $data['model'] ?? '',
                    $data['type'] ?? '',
                    $data['year'] ?? '',
                    $data['location'] ?? '',
                    $data['ownerId'] ?? '',
                    $data['ownerName'] ?? '',
                    $data['ownerEmail'] ?? '',
                    $data['pricePerDay'] ?? 0,
                    !empty($data['isAvailable']) ? 1 : 0,
                    json_encode($data['imageUrls'] ?? []),
                    $data['description'] ?? '',
                    $data['geoLat'] ?? null,
                    $data['geoLng'] ?? null,
                    $id,
                ]);
                echo json_encode(['ok'=>true]); exit;
            }
            if ($method === 'DELETE') {
                $stmt = $pdo->prepare('DELETE FROM vehicles WHERE id = ?');
                $stmt->execute([$id]);
                echo json_encode(['ok'=>true]); exit;
            }
        }
    }

    if ($resource === 'bookings') {
        if ($method === 'GET' && isset($_GET['vehicleId']) && isset($_GET['start']) && isset($_GET['end'])) {
            // Overlap check
            $vehicleId = $_GET['vehicleId'];
            $start = $_GET['start'];
            $end = $_GET['end'];
            $exclude = $_GET['excludeId'] ?? null;
            $stmt = $pdo->prepare('SELECT * FROM bookings WHERE vehicleId = ? AND NOT (endDate < ? OR startDate > ?)');
            $stmt->execute([$vehicleId, $start, $end]);
            $rows = $stmt->fetchAll();
            $overlap = false;
            foreach ($rows as $r) {
                if ($exclude && $r['id'] == $exclude) continue;
                if ($r['status'] === 'declined' || $r['status'] === 'cancelled') continue;
                $overlap = true; break;
            }
            echo json_encode(['overlap'=>$overlap]); exit;
        }

        if ($method === 'GET' && !$id) {
            // Get all bookings or filter by user/owner
            if (isset($parts[2]) && $parts[2] === 'user' && isset($parts[3])) {
                // GET /api/bookings/user/{userId}
                $userId = $parts[3];
                $stmt = $pdo->prepare('SELECT * FROM bookings WHERE renterId = ? ORDER BY createdAt DESC');
                $stmt->execute([$userId]);
            } elseif (isset($parts[2]) && $parts[2] === 'owner' && isset($parts[3])) {
                // GET /api/bookings/owner/{ownerId}
                $ownerId = $parts[3];
                $stmt = $pdo->prepare('SELECT * FROM bookings WHERE vehicleOwnerId = ? ORDER BY createdAt DESC');
                $stmt->execute([$ownerId]);
            } else {
                // GET all bookings (admin)
                $stmt = $pdo->query('SELECT * FROM bookings ORDER BY createdAt DESC');
            }
            $rows = $stmt->fetchAll();
            echo json_encode($rows); exit;
        }

        if ($method === 'POST') {
            $data = json_post();
            $now = date(DATE_ATOM);
            
            // Create renter user if doesn't exist
            $renterId = $data['renterId'] ?? null;
            $renterEmail = $data['renterEmail'] ?? '';
            $renterName = $data['renterName'] ?? '';
            
            if ($renterId) {
                $stmt = $pdo->prepare('SELECT uid FROM users WHERE uid = ?');
                $stmt->execute([$renterId]);
                if (!$stmt->fetch()) {
                    // User doesn't exist, create them
                    $stmt = $pdo->prepare('INSERT INTO users (uid, email, displayName, role) VALUES (?, ?, ?, ?)');
                    $stmt->execute([$renterId, $renterEmail, $renterName, 'user']);
                }
            }
            
            $stmt = $pdo->prepare('INSERT INTO bookings (vehicleId, vehicleBrand, vehicleModel, vehicleOwnerId, vehicleOwnerName, renterId, renterName, renterEmail, startDate, endDate, numberOfDays, totalPrice, status, notes, createdAt, updatedAt) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
            $stmt->execute([
                $data['vehicleId'] ?? '',
                $data['vehicleBrand'] ?? '',
                $data['vehicleModel'] ?? '',
                $data['vehicleOwnerId'] ?? '',
                $data['vehicleOwnerName'] ?? '',
                $data['renterId'] ?? '',
                $data['renterName'] ?? '',
                $data['renterEmail'] ?? '',
                $data['startDate'] ?? '',
                $data['endDate'] ?? '',
                $data['numberOfDays'] ?? 0,
                $data['totalPrice'] ?? 0.0,
                $data['status'] ?? 'pending',
                $data['notes'] ?? '',
                $now,
                null,
            ]);
            $id = $pdo->lastInsertId();
            http_response_code(201);
            echo json_encode(['id'=>$id, 'bookingId'=>$id]); exit;
        }

        if ($id && isset($parts[2]) && $parts[2] === 'status') {
            // /api/bookings/{id}/status
            if ($method === 'PUT') {
                $data = json_post();
                $status = $data['status'] ?? 'pending';
                $stmt = $pdo->prepare('UPDATE bookings SET status = ?, updatedAt = ? WHERE id = ?');
                $stmt->execute([$status, date(DATE_ATOM), $id]);
                echo json_encode(['ok'=>true]); exit;
            }
        }

        if ($id) {
            if ($method === 'GET') {
                $stmt = $pdo->prepare('SELECT * FROM bookings WHERE id = ?');
                $stmt->execute([$id]);
                $row = $stmt->fetch();
                if (!$row) { http_response_code(404); echo json_encode(['error'=>'not found']); exit; }
                echo json_encode($row); exit;
            }
            if ($method === 'PATCH') {
                $data = json_post();
                $status = $data['status'] ?? 'pending';
                $stmt = $pdo->prepare('UPDATE bookings SET status = ?, updatedAt = ? WHERE id = ?');
                $stmt->execute([$status, date(DATE_ATOM), $id]);
                echo json_encode(['ok'=>true]); exit;
            }
            if ($method === 'DELETE') {
                $stmt = $pdo->prepare('UPDATE bookings SET status = ?, updatedAt = ? WHERE id = ?');
                $stmt->execute(['cancelled', date(DATE_ATOM), $id]);
                echo json_encode(['ok'=>true]); exit;
            }
        }
    }

    http_response_code(404);
    echo json_encode(['error'=>'Not found']);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'server error', 'message' => $e->getMessage()]);
}
