<?php
// Database Configuration
// Fill in your MySQL connection details below

return [
    'host' => '127.0.0.1',          // MySQL host (localhost or IP)
    'port' => 3306,                 // MySQL port (default 3306)
    'dbname' => 'vehiclerental',    // Database name
    'user' => 'root',               // MySQL username
    'pass' => '',                   // MySQL password (empty by default for local dev)
];
