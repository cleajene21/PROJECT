<?php
// Seed sample vehicles into the database
// Access: http://localhost/vehiclerental-api/seed.php

header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/db.php';

try {
    // Sample vehicles to insert
    $vehicles = [
        [
            'brand' => 'Toyota',
            'model' => 'Camry',
            'type' => 'Sedan',
            'year' => '2023',
            'location' => 'Manila Downtown',
            'ownerId' => 'admin001',
            'ownerName' => 'John Smith',
            'ownerEmail' => 'john@example.com',
            'pricePerDay' => 2500,
            'isAvailable' => 1,
            'imageUrls' => json_encode(['https://via.placeholder.com/400x300?text=Toyota+Camry']),
            'description' => 'Comfortable sedan, great for family trips',
            'geoLat' => 14.5994,
            'geoLng' => 120.9842
        ],
        [
            'brand' => 'Honda',
            'model' => 'CR-V',
            'type' => 'SUV',
            'year' => '2022',
            'location' => 'Makati',
            'ownerId' => 'admin002',
            'ownerName' => 'Maria Santos',
            'ownerEmail' => 'maria@example.com',
            'pricePerDay' => 3500,
            'isAvailable' => 1,
            'imageUrls' => json_encode(['https://via.placeholder.com/400x300?text=Honda+CRV']),
            'description' => 'Spacious SUV, perfect for adventures',
            'geoLat' => 14.5547,
            'geoLng' => 121.0244
        ],
        [
            'brand' => 'Ford',
            'model' => 'Ranger',
            'type' => 'Pickup',
            'year' => '2023',
            'location' => 'Quezon City',
            'ownerId' => 'admin003',
            'ownerName' => 'Carlos Reyes',
            'ownerEmail' => 'carlos@example.com',
            'pricePerDay' => 3000,
            'isAvailable' => 1,
            'imageUrls' => json_encode(['https://via.placeholder.com/400x300?text=Ford+Ranger']),
            'description' => 'Powerful pickup truck',
            'geoLat' => 14.6349,
            'geoLng' => 121.0458
        ],
        [
            'brand' => 'Hyundai',
            'model' => 'Accent',
            'type' => 'Sedan',
            'year' => '2021',
            'location' => 'Pasig',
            'ownerId' => 'admin004',
            'ownerName' => 'Anna Lee',
            'ownerEmail' => 'anna@example.com',
            'pricePerDay' => 1800,
            'isAvailable' => 1,
            'imageUrls' => json_encode(['https://via.placeholder.com/400x300?text=Hyundai+Accent']),
            'description' => 'Budget-friendly compact sedan',
            'geoLat' => 14.5794,
            'geoLng' => 121.5734
        ],
        [
            'brand' => 'Nissan',
            'model' => 'Almera',
            'type' => 'Sedan',
            'year' => '2022',
            'location' => 'Las Piñas',
            'ownerId' => 'admin005',
            'ownerName' => 'Robert Cruz',
            'ownerEmail' => 'robert@example.com',
            'pricePerDay' => 2000,
            'isAvailable' => 1,
            'imageUrls' => json_encode(['https://via.placeholder.com/400x300?text=Nissan+Almera']),
            'description' => 'Reliable and economical',
            'geoLat' => 14.3521,
            'geoLng' => 120.9824
        ]
    ];

    // Insert vehicles
    $inserted = 0;
    foreach ($vehicles as $vehicle) {
        $stmt = $pdo->prepare('INSERT INTO vehicles (brand, model, type, year, location, ownerId, ownerName, ownerEmail, pricePerDay, isAvailable, imageUrls, description, geoLat, geoLng) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
        $stmt->execute([
            $vehicle['brand'],
            $vehicle['model'],
            $vehicle['type'],
            $vehicle['year'],
            $vehicle['location'],
            $vehicle['ownerId'],
            $vehicle['ownerName'],
            $vehicle['ownerEmail'],
            $vehicle['pricePerDay'],
            $vehicle['isAvailable'],
            $vehicle['imageUrls'],
            $vehicle['description'],
            $vehicle['geoLat'],
            $vehicle['geoLng']
        ]);
        $inserted++;
    }

    http_response_code(200);
    echo json_encode([
        'success' => true,
        'message' => "Successfully inserted $inserted sample vehicles",
        'count' => $inserted
    ], JSON_PRETTY_PRINT);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ], JSON_PRETTY_PRINT);
}
