Server API (PHP) - Setup

1) Prepare MySQL / phpMyAdmin
- Create a database named `vehiclerental` or import `server/sql/schema.sql` via phpMyAdmin.

2) Configure PHP
- Copy `server/php/config.sample.php` to `server/php/config.php` and fill DB credentials.

3) Serve the API
- Place the `server/php` folder under your web server's document root (e.g., XAMPP `htdocs/vehiclerental-api`), or configure a virtual host.
- Ensure `config.php` is readable by PHP and `pdo_mysql` is enabled.

4) Example endpoints
- POST /api/users        -> create user if not exists (JSON body with `uid`, `email`, ...)
- GET  /api/users/{uid}/role
- PUT  /api/users/{uid}/role  (JSON {"role":"owner"})
- GET  /api/vehicles
- POST /api/vehicles      -> add vehicle (JSON body)
- GET  /api/vehicles/{id}
- PUT  /api/vehicles/{id}
- DELETE /api/vehicles/{id}
- GET  /api/bookings?vehicleId=...&start=...&end=...  -> overlap check
- GET  /api/bookings
- POST /api/bookings
- PUT  /api/bookings/{id}/status

5) Point your Flutter app to the API
- Edit `lib/services/firestore_service.dart` and set `API_BASE` to your API host, e.g.:
  `const String API_BASE = 'http://10.0.2.2/vehiclerental-api/api';` for Android emulator
  or `http://localhost/vehiclerental-api/api` for desktop/web host reachable locally.

6) phpMyAdmin
- Use phpMyAdmin to browse tables and run queries. Import `server/sql/schema.sql` if needed.

Notes
- This is a minimal example API intended for local testing. Harden, validate inputs, and add auth/ACL for production.
