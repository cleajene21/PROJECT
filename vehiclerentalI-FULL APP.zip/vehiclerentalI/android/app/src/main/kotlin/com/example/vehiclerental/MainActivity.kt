package com.example.vehiclerental

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
