# phpMyAdmin & API Setup Guide

## ✅ Status Check
- MySQL: **RUNNING** (Port 3306)
- Apache: **RUNNING** (Port 80)
- phpMyAdmin: **ACCESSIBLE** (http://localhost/phpmyadmin/)

## 📋 Step 1: Create Database via phpMyAdmin

1. **Open phpMyAdmin**: 
2. **Click the "SQL" tab** at the top
3. **Copy & paste the entire SQL schema** from `server/sql/schema.sql`
4. **Click "Go"** to execute and create the database

OR use Import:
1. Click **Import** tab
2. Click **Choose File** → select `server/sql/schema.sql`
3. Click **Go**

## 📁 Step 2: Copy PHP Files to XAMPP

Your PHP API files need to be in XAMPP's `htdocs` folder:

**Copy the entire `server/php` folder to:**
```
C:\xampp\htdocs\vehiclerental-api\
```

After copying, your structure should be:
```
C:\xampp\htdocs\
└── vehiclerental-api/
    ├── config.php
    ├── db.php
    ├── health.php
    ├── index.php
    ├── seed.php
    └── .htaccess
```

## 🧪 Step 3: Test the API

Once copied, test with:
```
http://localhost/vehiclerental-api/api/vehicles
```

Should return: `[]` (empty list)

## 🔧 Step 4: Update Flutter App

In your Flutter app, update the API base URL:

**File: lib/services/vehicle_service.dart**
```dart
const String baseUrl = 'http://localhost/vehiclerental-api/api';
```

Or for Android emulator:
```dart
const String baseUrl = 'http://10.0.2.2/vehiclerental-api/api';
```

## 📝 Database Tables Created

✅ **users** - User accounts with roles (user/admin)
✅ **vehicles** - Vehicle listings with owner info
✅ **bookings** - Rental bookings with status tracking

You can view these tables in phpMyAdmin under the `vehiclerental` database!

## 🐛 Troubleshooting

**Can't access http://localhost/phpmyadmin/?**
- Check Apache is running: `netstat -ano | findstr ":80"`
- Restart Apache from XAMPP Control Panel

**Database not created?**
- Check MySQL is running: `netstat -ano | findstr ":3306"`
- Make sure to execute the full SQL script

**API returns 404?**
- Verify files are in `C:\xampp\htdocs\vehiclerental-api\`
- Check `.htaccess` file exists
- Ensure `pdo_mysql` is enabled in PHP
