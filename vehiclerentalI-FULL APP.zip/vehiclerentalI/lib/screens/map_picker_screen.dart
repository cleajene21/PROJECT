import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

import '../models/vehicle.dart';

class MapPickerScreen extends StatefulWidget {
  final GeoLocation? initialLocation;
  final bool readOnly;

  const MapPickerScreen(
      {super.key, this.initialLocation, this.readOnly = false});

  @override
  State<MapPickerScreen> createState() => _MapPickerScreenState();
}

class _MapPickerScreenState extends State<MapPickerScreen> {
  LatLng? _picked;
  final MapController _mapController = MapController();
  String _address = '';
  bool _loadingAddress = false;

  @override
  void initState() {
    super.initState();
    if (widget.initialLocation != null) {
      _picked = LatLng(
          widget.initialLocation!.latitude, widget.initialLocation!.longitude);
      // Center map on initial location after first frame
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) {
          _mapController.move(_picked!, 15.0);
          _reverseGeocode(_picked!);
        }
      });
    } else {
      _determinePosition().then((pos) {
        if (mounted) {
          _mapController.move(LatLng(pos.latitude, pos.longitude), 15.0);
        }
      }).catchError((_) {});
    }
  }

  Future<Position> _determinePosition() async {
    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      throw Exception('Location services are disabled.');
    }

    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        throw Exception('Location permissions are denied');
      }
    }

    if (permission == LocationPermission.deniedForever) {
      throw Exception('Location permissions are permanently denied');
    }

    return await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(
      accuracy: LocationAccuracy.high,
    ));
  }

  Future<void> _reverseGeocode(LatLng latlng) async {
    setState(() => _loadingAddress = true);
    try {
      final url = Uri.parse(
          'https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${latlng.latitude}&lon=${latlng.longitude}');
      final res =
          await http.get(url, headers: {'User-Agent': 'vehiclerental-app/1.0'});
      if (res.statusCode == 200) {
        final data = json.decode(res.body);
        setState(() {
          _address = (data['display_name'] as String?) ?? '';
        });
      }
    } catch (e) {
      // ignore
    } finally {
      setState(() => _loadingAddress = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final center =
        _picked ?? const LatLng(14.5995, 120.9842); // Manila fallback

    return Scaffold(
      appBar: AppBar(
        title: const Text('Pick Location'),
        actions: [
          if (!widget.readOnly)
            TextButton(
              onPressed: _picked == null
                  ? null
                  : () {
                      final geo = GeoLocation(
                          latitude: _picked!.latitude,
                          longitude: _picked!.longitude);
                      Navigator.pop(context, {'geo': geo, 'address': _address});
                    },
              child:
                  const Text('Confirm', style: TextStyle(color: Colors.white)),
            ),
        ],
      ),
      body: Stack(
        children: [
          FlutterMap(
            mapController: _mapController,
            options: MapOptions(
              initialCenter: center,
              initialZoom: 13.0,
              onTap: widget.readOnly
                  ? null
                  : (tapPos, latlng) async {
                      setState(() {
                        _picked = latlng;
                      });
                      await _reverseGeocode(latlng);
                    },
            ),
            children: [
              TileLayer(
                urlTemplate:
                    'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
                subdomains: const ['a', 'b', 'c'],
                userAgentPackageName: 'org.example.vehiclerental',
              ),
              if (_picked != null)
                MarkerLayer(
                  markers: [
                    Marker(
                      point: _picked!,
                      width: 80,
                      height: 80,
                      child: const Icon(Icons.location_pin,
                          size: 48, color: Colors.red),
                    ),
                  ],
                ),
            ],
          ),
          Positioned(
            right: 12,
            top: 12,
            child: Card(
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Column(
                  children: [
                    IconButton(
                      icon: const Icon(Icons.my_location),
                      onPressed: () async {
                        try {
                          final pos = await _determinePosition();
                          if (!mounted) return;
                          _mapController.move(
                              LatLng(pos.latitude, pos.longitude), 15.0);
                        } catch (e) {
                          if (!mounted) return;
                          ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(content: Text('Error: $e')));
                        }
                      },
                    ),
                    const SizedBox(height: 6),
                    if (!widget.readOnly)
                      IconButton(
                        icon: const Icon(Icons.search),
                        onPressed: () async {
                          // simple prompt to search by coordinates or address via nominatim? keep simple
                          final q = await showDialog<String?>(
                            context: context,
                            builder: (context) {
                              final ctrl = TextEditingController();
                              return AlertDialog(
                                title: const Text('Search location'),
                                content: TextField(
                                    controller: ctrl,
                                    decoration: const InputDecoration(
                                        hintText: 'Address or lat,lon')),
                                actions: [
                                  TextButton(
                                      onPressed: () => Navigator.pop(context),
                                      child: const Text('Cancel')),
                                  TextButton(
                                      onPressed: () => Navigator.pop(
                                          context, ctrl.text.trim()),
                                      child: const Text('Search')),
                                ],
                              );
                            },
                          );
                          if (q != null && q.isNotEmpty) {
                            // try geocoding via nominatim
                            try {
                              final url = Uri.parse(
                                  'https://nominatim.openstreetmap.org/search?format=jsonv2&q=${Uri.encodeComponent(q)}');
                              final res = await http.get(url, headers: {
                                'User-Agent': 'vehiclerental-app/1.0'
                              });
                              if (res.statusCode == 200) {
                                final arr = json.decode(res.body) as List;
                                if (arr.isNotEmpty) {
                                  final lat = double.parse(arr[0]['lat']);
                                  final lon = double.parse(arr[0]['lon']);
                                  final latlng = LatLng(lat, lon);
                                  _mapController.move(latlng, 15.0);
                                  setState(() {
                                    _picked = latlng;
                                  });
                                  await _reverseGeocode(latlng);
                                }
                              }
                            } catch (e) {
                              if (!mounted) return;
                              ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(content: Text('Search error: $e')));
                            }
                          }
                        },
                      ),
                  ],
                ),
              ),
            ),
          ),
          Positioned(
            left: 12,
            bottom: 12,
            right: 12,
            child: Card(
              child: Padding(
                padding: const EdgeInsets.all(12.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(_loadingAddress
                        ? 'Looking up address...'
                        : (_address.isEmpty
                            ? 'Tap map to pick location'
                            : _address)),
                    const SizedBox(height: 8),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        TextButton(
                          onPressed: () => Navigator.pop(context),
                          child: const Text('Close'),
                        ),
                        const SizedBox(width: 8),
                        if (!widget.readOnly)
                          ElevatedButton(
                            onPressed: _picked == null
                                ? null
                                : () {
                                    final geo = GeoLocation(
                                        latitude: _picked!.latitude,
                                        longitude: _picked!.longitude);
                                    Navigator.pop(context,
                                        {'geo': geo, 'address': _address});
                                  },
                            child: const Text('Use this location'),
                          ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
