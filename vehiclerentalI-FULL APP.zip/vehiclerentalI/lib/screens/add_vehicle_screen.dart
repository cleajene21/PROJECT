import 'dart:io';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:image_picker/image_picker.dart';
import '../models/vehicle.dart';
import '../services/vehicle_service.dart';
import '../services/storage_service.dart';
import 'map_picker_screen.dart';

class AddVehicleScreen extends StatefulWidget {
  final Vehicle? vehicle;

  const AddVehicleScreen({super.key, this.vehicle});

  @override
  State<AddVehicleScreen> createState() => _AddVehicleScreenState();
}

class _AddVehicleScreenState extends State<AddVehicleScreen> {
  final _formKey = GlobalKey<FormState>();
  final _brandCtrl = TextEditingController();
  final _modelCtrl = TextEditingController();
  final _yearCtrl = TextEditingController();
  final _priceCtrl = TextEditingController();
  final _descriptionCtrl = TextEditingController();
  final _locationCtrl = TextEditingController();

  final StorageService _storage = StorageService();

  String _selectedType = 'Sedan';
  bool _isAvailable = true;
  bool _loading = false;
  List<XFile> _selectedImages = [];
  List<String> _existingImageUrls = [];
  GeoLocation? _geoLocation;

  final List<String> _vehicleTypes = [
    'Sedan',
    'SUV',
    'Hatchback',
    'Coupe',
    'Convertible',
    'Motorcycle',
    'Truck',
    'Van',
    'Other',
  ];

  @override
  void initState() {
    super.initState();
    if (widget.vehicle != null) {
      _loadVehicleData();
    }
  }

  void _loadVehicleData() {
    final vehicle = widget.vehicle!;
    _brandCtrl.text = vehicle.brand;
    _modelCtrl.text = vehicle.model;
    _yearCtrl.text = vehicle.year;
    _priceCtrl.text = vehicle.pricePerDay.toString();
    _descriptionCtrl.text = vehicle.description ?? '';
    _locationCtrl.text = vehicle.location;
    _selectedType = vehicle.type;
    _isAvailable = vehicle.isAvailable;
    _existingImageUrls = vehicle.imageUrls;
    _geoLocation = vehicle.geoLocation;
  }

  @override
  void dispose() {
    _brandCtrl.dispose();
    _modelCtrl.dispose();
    _yearCtrl.dispose();
    _priceCtrl.dispose();
    _descriptionCtrl.dispose();
    _locationCtrl.dispose();
    super.dispose();
  }

  Future<void> _pickImages() async {
    try {
      final images = await _storage.pickImages(maxImages: 5);
      setState(() {
        _selectedImages = images;
      });
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error picking images: $e')),
        );
      }
    }
  }

  Future<void> _pickLocation() async {
    final result = await Navigator.push<Map<String, dynamic>>(
      context,
      MaterialPageRoute(
        builder: (_) => MapPickerScreen(
          initialLocation: _geoLocation,
          readOnly: false,
        ),
      ),
    );

    if (result != null && mounted) {
      setState(() {
        _geoLocation = result['geo'] as GeoLocation?;
        final address = result['address'] as String?;
        if (address != null && address.isNotEmpty) {
          _locationCtrl.text = address;
        }
      });
    }
  }

  Future<void> _saveVehicle() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _loading = true);

    try {
      final user = FirebaseAuth.instance.currentUser!;

      final displayName = user.displayName ?? 'Owner';
      final email = user.email ?? '';

      String vehicleId = widget.vehicle?.id ?? '';
      List<String> imageUrls = List.from(_existingImageUrls);

      if (_selectedImages.isNotEmpty) {
        if (vehicleId.isEmpty) {
          vehicleId = DateTime.now().millisecondsSinceEpoch.toString();
        }
        final uploadedUrls =
            await _storage.uploadVehicleImages(vehicleId, _selectedImages);
        imageUrls.addAll(uploadedUrls);
      }

      final vehicle = Vehicle(
        id: widget.vehicle?.id,
        ownerId: user.uid,
        ownerName: displayName,
        ownerEmail: email,
        brand: _brandCtrl.text.trim(),
        model: _modelCtrl.text.trim(),
        type: _selectedType,
        year: _yearCtrl.text.trim(),
        pricePerDay: double.parse(_priceCtrl.text.trim()),
        description: _descriptionCtrl.text.trim(),
        imageUrls: imageUrls,
        location: _locationCtrl.text.trim(),
        geoLocation: _geoLocation,
        isAvailable: _isAvailable,
        createdAt: widget.vehicle?.createdAt ?? DateTime.now(),
        updatedAt: DateTime.now(),
      );

      if (widget.vehicle == null) {
        vehicleId = await VehicleService.addVehicle(vehicle);
      } else {
        await VehicleService.updateVehicle(vehicle);
      }

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(widget.vehicle == null
                ? 'Vehicle added successfully!'
                : 'Vehicle updated successfully!'),
            backgroundColor: Colors.green,
          ),
        );
        Navigator.pop(context, true);
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          widget.vehicle == null ? 'Add Vehicle' : 'Edit Vehicle',
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
        elevation: 0,
        backgroundColor: Colors.blue.shade700,
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Colors.blue.shade50, Colors.white],
          ),
        ),
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const Text(
                  'Vehicle Images',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 8),
                SizedBox(
                  height: 120,
                  child: ListView.builder(
                    scrollDirection: Axis.horizontal,
                    itemCount:
                        _existingImageUrls.length + _selectedImages.length + 1,
                    itemBuilder: (context, index) {
                      if (index < _existingImageUrls.length) {
                        return _buildImagePreview(_existingImageUrls[index],
                            isUrl: true, index: index);
                      } else if (index <
                          _existingImageUrls.length + _selectedImages.length) {
                        final fileIndex = index - _existingImageUrls.length;
                        return _buildImagePreview(
                            _selectedImages[fileIndex].path,
                            isUrl: false,
                            index: index);
                      } else {
                        return _buildAddImageButton();
                      }
                    },
                  ),
                ),
                const SizedBox(height: 24),
                TextFormField(
                  controller: _brandCtrl,
                  decoration: const InputDecoration(
                    labelText: 'Brand *',
                    border: OutlineInputBorder(),
                  ),
                  validator: (v) => v?.isEmpty ?? true ? 'Required' : null,
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _modelCtrl,
                  decoration: const InputDecoration(
                    labelText: 'Model *',
                    border: OutlineInputBorder(),
                  ),
                  validator: (v) => v?.isEmpty ?? true ? 'Required' : null,
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: DropdownButtonFormField<String>(
                        value: _selectedType,
                        decoration: const InputDecoration(
                          labelText: 'Type *',
                          border: OutlineInputBorder(),
                        ),
                        items: _vehicleTypes
                            .map((type) => DropdownMenuItem(
                                  value: type,
                                  child: Text(type),
                                ))
                            .toList(),
                        onChanged: (value) =>
                            setState(() => _selectedType = value!),
                      ),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: TextFormField(
                        controller: _yearCtrl,
                        decoration: const InputDecoration(
                          labelText: 'Year *',
                          border: OutlineInputBorder(),
                        ),
                        keyboardType: TextInputType.number,
                        validator: (v) =>
                            v?.isEmpty ?? true ? 'Required' : null,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _priceCtrl,
                  decoration: const InputDecoration(
                    labelText: 'Price per Day (₱) *',
                    border: OutlineInputBorder(),
                    prefixText: '₱ ',
                  ),
                  keyboardType: TextInputType.number,
                  validator: (v) {
                    if (v?.isEmpty ?? true) return 'Required';
                    if (double.tryParse(v!) == null) return 'Invalid number';
                    return null;
                  },
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _locationCtrl,
                  decoration: InputDecoration(
                    labelText: 'Location *',
                    border: const OutlineInputBorder(),
                    suffixIcon: IconButton(
                      icon: const Icon(Icons.location_on),
                      onPressed: _pickLocation,
                    ),
                  ),
                  validator: (v) => v?.isEmpty ?? true ? 'Required' : null,
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _descriptionCtrl,
                  decoration: const InputDecoration(
                    labelText: 'Description',
                    border: OutlineInputBorder(),
                  ),
                  maxLines: 3,
                ),
                const SizedBox(height: 16),
                SwitchListTile(
                  title: const Text('Available for Rent'),
                  value: _isAvailable,
                  onChanged: (value) => setState(() => _isAvailable = value),
                ),
                const SizedBox(height: 24),
                SizedBox(
                  height: 50,
                  child: ElevatedButton(
                    onPressed: _loading ? null : _saveVehicle,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.blue.shade700,
                    ),
                    child: _loading
                        ? const CircularProgressIndicator(color: Colors.white)
                        : Text(
                            widget.vehicle == null
                                ? 'Add Vehicle'
                                : 'Update Vehicle',
                            style: const TextStyle(
                                fontSize: 16, fontWeight: FontWeight.bold),
                          ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildImagePreview(String path,
      {required bool isUrl, required int index}) {
    return Container(
      width: 120,
      margin: const EdgeInsets.only(right: 8),
      child: Stack(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: isUrl
                ? Image.network(path,
                    fit: BoxFit.cover, height: 120, width: 120)
                : Image.file(
                    File(path),
                    fit: BoxFit.cover,
                    height: 120,
                    width: 120,
                  ),
          ),
          Positioned(
            top: 4,
            right: 4,
            child: CircleAvatar(
              radius: 12,
              backgroundColor: Colors.red,
              child: IconButton(
                padding: EdgeInsets.zero,
                iconSize: 16,
                icon: const Icon(Icons.close, color: Colors.white),
                onPressed: () {
                  setState(() {
                    if (isUrl) {
                      _existingImageUrls.removeAt(index);
                    } else {
                      _selectedImages
                          .removeAt(index - _existingImageUrls.length);
                    }
                  });
                },
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAddImageButton() {
    return Container(
      width: 120,
      margin: const EdgeInsets.only(right: 8),
      child: InkWell(
        onTap: _pickImages,
        borderRadius: BorderRadius.circular(8),
        child: Container(
          decoration: BoxDecoration(
            border: Border.all(color: Colors.grey.shade300),
            borderRadius: BorderRadius.circular(8),
          ),
          child: const Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.add_photo_alternate, size: 40, color: Colors.grey),
              SizedBox(height: 4),
              Text('Add Image',
                  style: TextStyle(color: Colors.grey, fontSize: 12)),
            ],
          ),
        ),
      ),
    );
  }
}
