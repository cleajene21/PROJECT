// GENERATED FILE - DO NOT MODIFY BY HAND
// ignore_for_file: public_member_api_docs, constant_identifier_names

import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart'
    show defaultTargetPlatform, kIsWeb, TargetPlatform;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) {
      return web;
    }
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      case TargetPlatform.iOS:
        return ios;
      case TargetPlatform.macOS:
        return ios;
      default:
        throw UnsupportedError(
          'DefaultFirebaseOptions are not supported for this platform.',
        );
    }
  }

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyA9fSZdfxmco_btJw1AVzGGtMvyFwCWkgw',
    appId: '1:192490966146:android:76d9bc7a7f6d50d41e789b',
    messagingSenderId: '192490966146',
    projectId: 'vehiclerentalapp-eb14c',
    storageBucket: 'vehiclerentalapp-eb14c.firebasestorage.app',
  );

  static const FirebaseOptions ios = FirebaseOptions(
    apiKey: 'AIzaSyA75xZcMIZMctwBLs3EYA6ZnYxziwTXqy0',
    appId: '1:192490966146:ios:2299dd4f63f2aecc1e789b',
    messagingSenderId: '192490966146',
    projectId: 'vehiclerentalapp-eb14c',
    storageBucket: 'vehiclerentalapp-eb14c.firebasestorage.app',
    iosBundleId: 'com.example.vehiclerentalapp',
  );

  // Web configuration
  // NOTE: Replace the placeholder values below with the actual web app
  // configuration from the Firebase Console (Project settings -> Your apps -> Web app).
  static const FirebaseOptions web = FirebaseOptions(
    apiKey: "AIzaSyDTrxQc2eEEWTBN-9paONBS49ulUi8-woc",
    authDomain: "vehiclerentalapp-eb14c.firebaseapp.com",
    projectId: "vehiclerentalapp-eb14c",
    storageBucket: "vehiclerentalapp-eb14c.firebasestorage.app",
    messagingSenderId: "192490966146",
    appId: "1:192490966146:web:a9b708657feab6981e789b",
    measurementId: "G-508R21GTFJ",
  );
}
