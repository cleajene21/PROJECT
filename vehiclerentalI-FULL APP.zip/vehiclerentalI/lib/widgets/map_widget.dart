import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';

class MapWidget extends StatefulWidget {
  final LatLng initialLocation;
  final List<Marker>? markers;
  final VoidCallback? onMapTap;

  const MapWidget({
    super.key,
    this.initialLocation = const LatLng(14.5995, 120.9842), // Default: Manila
    this.markers,
    this.onMapTap,
  });

  @override
  State<MapWidget> createState() => _MapWidgetState();
}

class _MapWidgetState extends State<MapWidget> {
  late MapController _mapController;

  @override
  void initState() {
    super.initState();
    _mapController = MapController();
  }

  @override
  void dispose() {
    _mapController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(12),
      child: FlutterMap(
        mapController: _mapController,
        options: MapOptions(
          initialCenter: widget.initialLocation,
          initialZoom: 13.0,
          minZoom: 2.0,
          maxZoom: 18.0,
          onTap: (tapPosition, point) {
            widget.onMapTap?.call();
          },
        ),
        children: [
          TileLayer(
            urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
            userAgentPackageName: 'com.example.vehiclerental',
          ),
          MarkerLayer(
            markers: [
              // Default center marker
              Marker(
                point: widget.initialLocation,
                width: 40,
                height: 40,
                child: Icon(
                  Icons.location_on,
                  color: Colors.red.shade700,
                  size: 40,
                ),
              ),
              // Custom markers if provided
              if (widget.markers != null) ...widget.markers!,
            ],
          ),
          Positioned(
            bottom: 16,
            right: 16,
            child: Column(
              children: [
                // Zoom in button
                FloatingActionButton(
                  mini: true,
                  backgroundColor: Colors.white,
                  onPressed: () {
                    _mapController.move(
                      _mapController.camera.center,
                      _mapController.camera.zoom + 1,
                    );
                  },
                  child: Icon(
                    Icons.add,
                    color: Colors.blue.shade700,
                  ),
                ),
                const SizedBox(height: 8),
                // Zoom out button
                FloatingActionButton(
                  mini: true,
                  backgroundColor: Colors.white,
                  onPressed: () {
                    _mapController.move(
                      _mapController.camera.center,
                      _mapController.camera.zoom - 1,
                    );
                  },
                  child: Icon(
                    Icons.remove,
                    color: Colors.blue.shade700,
                  ),
                ),
                const SizedBox(height: 8),
                // Center button
                FloatingActionButton(
                  mini: true,
                  backgroundColor: Colors.white,
                  onPressed: () {
                    _mapController.move(
                      widget.initialLocation,
                      13.0,
                    );
                  },
                  child: Icon(
                    Icons.my_location,
                    color: Colors.blue.shade700,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
