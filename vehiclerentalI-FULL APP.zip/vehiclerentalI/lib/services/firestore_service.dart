import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/vehicle.dart';
import '../models/booking.dart';

class FirestoreService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  // User Methods
  Future<void> createUserIfNotExists({required String uid, String? email, String? displayName, bool emailVerified = false}) async {
    final docRef = _firestore.collection('users').doc(uid);
    final snap = await docRef.get();
    if (!snap.exists) {
      await docRef.set({
        'email': email ?? '',
        'displayName': displayName ?? '',
        'role': 'user',
        'emailVerified': emailVerified,
        'createdAt': FieldValue.serverTimestamp(),
      });
    } else {
      // Update emailVerified flag if changed
      final data = snap.data();
      if (data != null && (data['emailVerified'] as bool?) != emailVerified) {
        await docRef.update({'emailVerified': emailVerified});
      }
    }
  }

  Future<String> getRole(String uid) async {
    final snap = await _firestore.collection('users').doc(uid).get();
    if (!snap.exists) return 'user';
    final data = snap.data();
    return (data?['role'] as String?) ?? 'user';
  }

  // Vehicle Methods
  Future<String> addVehicle(Vehicle vehicle) async {
    final docRef = _firestore.collection('vehicles').doc();
    await docRef.set(vehicle.toFirestore());
    return docRef.id;
  }

  Future<void> updateVehicle(Vehicle vehicle) async {
    if (vehicle.id == null) throw Exception('Vehicle ID is required for update');
    await _firestore.collection('vehicles').doc(vehicle.id).update(
      vehicle.copyWith(updatedAt: DateTime.now()).toFirestore(),
    );
  }

  Future<void> deleteVehicle(String vehicleId) async {
    await _firestore.collection('vehicles').doc(vehicleId).delete();
  }

  Stream<List<Vehicle>> getVehicles() {
    return _firestore
        .collection('vehicles')
        .where('isAvailable', isEqualTo: true)
        .snapshots()
        .map((snapshot) {
          final vehicles = snapshot.docs
              .map((doc) => Vehicle.fromFirestore(doc.id, doc.data()))
              .toList();
          // Sort in memory as fallback if index is not yet created
          vehicles.sort((a, b) => b.createdAt.compareTo(a.createdAt));
          return vehicles;
        });
  }

  Stream<List<Vehicle>> getVehiclesByOwner(String ownerId) {
    return _firestore
        .collection('vehicles')
        .where('ownerId', isEqualTo: ownerId)
        .snapshots()
        .map((snapshot) {
          final vehicles = snapshot.docs
              .map((doc) => Vehicle.fromFirestore(doc.id, doc.data()))
              .toList();
          // Sort in memory as fallback if index is not yet created
          vehicles.sort((a, b) => b.createdAt.compareTo(a.createdAt));
          return vehicles;
        });
  }

  Future<Vehicle?> getVehicle(String vehicleId) async {
    final doc = await _firestore.collection('vehicles').doc(vehicleId).get();
    if (!doc.exists) return null;
    return Vehicle.fromFirestore(doc.id, doc.data()!);
  }

  // Booking Methods
  Future<String> createBooking(Booking booking) async {
    // Check for overlapping bookings
    final overlaps = await checkBookingOverlap(booking.vehicleId, booking.startDate, booking.endDate, booking.id);
    if (overlaps) {
      throw Exception('This vehicle is already booked for the selected dates');
    }

    final docRef = _firestore.collection('bookings').doc();
    await docRef.set(booking.toFirestore());
    return docRef.id;
  }

  Future<bool> checkBookingOverlap(String vehicleId, DateTime startDate, DateTime endDate, [String? excludeBookingId]) async {
    final query = _firestore
        .collection('bookings')
        .where('vehicleId', isEqualTo: vehicleId)
        .where('status', whereIn: ['pending', 'approved']);

    final snapshot = await query.get();
    
    for (var doc in snapshot.docs) {
      if (excludeBookingId != null && doc.id == excludeBookingId) continue;
      
      final booking = Booking.fromFirestore(doc.id, doc.data());
      if (booking.overlapsWith(Booking(
        vehicleId: vehicleId,
        vehicleBrand: '',
        vehicleModel: '',
        vehicleOwnerId: '',
        vehicleOwnerName: '',
        renterId: '',
        renterName: '',
        renterEmail: '',
        startDate: startDate,
        endDate: endDate,
        numberOfDays: 0,
        totalPrice: 0,
        createdAt: DateTime.now(),
      ))) {
        return true;
      }
    }
    return false;
  }

  Future<void> updateBookingStatus(String bookingId, BookingStatus status) async {
    await _firestore.collection('bookings').doc(bookingId).update({
      'status': status.value,
      'updatedAt': DateTime.now().toIso8601String(),
    });
  }

  Future<void> deleteBooking(String bookingId) async {
    await _firestore.collection('bookings').doc(bookingId).delete();
  }

  Stream<List<Booking>> getBookingsByRenter(String renterId) {
    return _firestore
        .collection('bookings')
        .where('renterId', isEqualTo: renterId)
        .snapshots()
        .map((snapshot) {
          final bookings = snapshot.docs
              .map((doc) => Booking.fromFirestore(doc.id, doc.data()))
              .toList();
          // Sort in memory as fallback if index is not yet created
          bookings.sort((a, b) => b.createdAt.compareTo(a.createdAt));
          return bookings;
        });
  }

  Stream<List<Booking>> getBookingsByOwner(String ownerId) {
    return _firestore
        .collection('bookings')
        .where('vehicleOwnerId', isEqualTo: ownerId)
        .snapshots()
        .map((snapshot) {
          final bookings = snapshot.docs
              .map((doc) => Booking.fromFirestore(doc.id, doc.data()))
              .toList();
          // Sort in memory as fallback if index is not yet created
          bookings.sort((a, b) => b.createdAt.compareTo(a.createdAt));
          return bookings;
        });
  }

  Future<Booking?> getBooking(String bookingId) async {
    final doc = await _firestore.collection('bookings').doc(bookingId).get();
    if (!doc.exists) return null;
    return Booking.fromFirestore(doc.id, doc.data()!);
  }
}
