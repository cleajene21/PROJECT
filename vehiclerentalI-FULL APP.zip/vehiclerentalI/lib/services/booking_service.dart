import 'package:http/http.dart' as http;
import 'dart:convert';
import '../models/booking.dart'
    show Booking, BookingStatusExtension, bookingStatusFromString;

class BookingService {
  // Use the same base URL as VehicleService
  static const String baseUrl = 'http://localhost:80/vehiclerental-api';

  /// Create a new booking in MySQL database
  static Future<String> createBooking(Booking booking) async {
    try {
      final response = await http
          .post(
            Uri.parse('$baseUrl/api/bookings'),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({
              'vehicleId': booking.vehicleId,
              'vehicleBrand': booking.vehicleBrand,
              'vehicleModel': booking.vehicleModel,
              'vehicleOwnerId': booking.vehicleOwnerId,
              'vehicleOwnerName': booking.vehicleOwnerName,
              'renterId': booking.renterId,
              'renterName': booking.renterName,
              'renterEmail': booking.renterEmail,
              'startDate': booking.startDate.toIso8601String(),
              'endDate': booking.endDate.toIso8601String(),
              'numberOfDays': booking.numberOfDays,
              'totalPrice': booking.totalPrice,
              'status': booking.status.value,
              'notes': booking.notes ?? '',
              'createdAt': booking.createdAt.toIso8601String(),
            }),
          )
          .timeout(const Duration(seconds: 10));

      if (response.statusCode == 201 || response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final bookingId =
            data['id']?.toString() ?? data['bookingId']?.toString() ?? '0';
        if (bookingId == '0') {
          throw Exception('Failed to get booking ID from response');
        }
        return bookingId;
      } else {
        throw Exception(
            'Failed to create booking: ${response.statusCode} - ${response.body}');
      }
    } catch (e) {
      throw Exception('Error creating booking: $e');
    }
  }

  /// Get all bookings for a specific user (renter)
  static Future<List<Booking>> getUserBookings(String userId) async {
    try {
      final response = await http
          .get(
            Uri.parse('$baseUrl/api/bookings/user/$userId'),
          )
          .timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final List<dynamic> data = jsonDecode(response.body);
        return data
            .map((b) => Booking(
                  id: b['id']?.toString(),
                  vehicleId: b['vehicleId'].toString(),
                  vehicleBrand: b['vehicleBrand'] ?? '',
                  vehicleModel: b['vehicleModel'] ?? '',
                  vehicleOwnerId: b['vehicleOwnerId'] ?? '',
                  vehicleOwnerName: b['vehicleOwnerName'] ?? '',
                  renterId: b['renterId'] ?? '',
                  renterName: b['renterName'] ?? '',
                  renterEmail: b['renterEmail'] ?? '',
                  startDate: DateTime.parse(b['startDate'].toString()),
                  endDate: DateTime.parse(b['endDate'].toString()),
                  numberOfDays: int.parse(b['numberOfDays'].toString()),
                  totalPrice: double.parse(b['totalPrice'].toString()),
                  status: bookingStatusFromString(b['status'] ?? 'pending'),
                  notes: b['notes'],
                  createdAt: DateTime.parse(b['createdAt'].toString()),
                  updatedAt: b['updatedAt'] != null
                      ? DateTime.parse(b['updatedAt'].toString())
                      : null,
                ))
            .toList();
      } else {
        throw Exception('Failed to load bookings: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Error fetching bookings: $e');
    }
  }

  /// Get all bookings for a vehicle owner
  static Future<List<Booking>> getOwnerBookings(String ownerId) async {
    try {
      final response = await http
          .get(
            Uri.parse('$baseUrl/api/bookings/owner/$ownerId'),
          )
          .timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final List<dynamic> data = jsonDecode(response.body);
        return data
            .map((b) => Booking(
                  id: b['id']?.toString(),
                  vehicleId: b['vehicleId'].toString(),
                  vehicleBrand: b['vehicleBrand'] ?? '',
                  vehicleModel: b['vehicleModel'] ?? '',
                  vehicleOwnerId: b['vehicleOwnerId'] ?? '',
                  vehicleOwnerName: b['vehicleOwnerName'] ?? '',
                  renterId: b['renterId'] ?? '',
                  renterName: b['renterName'] ?? '',
                  renterEmail: b['renterEmail'] ?? '',
                  startDate: DateTime.parse(b['startDate'].toString()),
                  endDate: DateTime.parse(b['endDate'].toString()),
                  numberOfDays: int.parse(b['numberOfDays'].toString()),
                  totalPrice: double.parse(b['totalPrice'].toString()),
                  status: bookingStatusFromString(b['status'] ?? 'pending'),
                  notes: b['notes'],
                  createdAt: DateTime.parse(b['createdAt'].toString()),
                  updatedAt: b['updatedAt'] != null
                      ? DateTime.parse(b['updatedAt'].toString())
                      : null,
                ))
            .toList();
      } else {
        throw Exception('Failed to load bookings: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Error fetching bookings: $e');
    }
  }

  /// Update booking status
  static Future<void> updateBookingStatus(
      String bookingId, String newStatus) async {
    try {
      final response = await http
          .patch(
            Uri.parse('$baseUrl/api/bookings/$bookingId'),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({
              'status': newStatus,
            }),
          )
          .timeout(const Duration(seconds: 10));

      if (response.statusCode != 200) {
        throw Exception('Failed to update booking: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Error updating booking: $e');
    }
  }

  /// Cancel a booking
  static Future<void> cancelBooking(String bookingId) async {
    try {
      final response = await http
          .delete(
            Uri.parse('$baseUrl/api/bookings/$bookingId'),
          )
          .timeout(const Duration(seconds: 10));

      if (response.statusCode != 200) {
        throw Exception('Failed to cancel booking: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Error cancelling booking: $e');
    }
  }

  /// Get a single booking by ID
  static Future<Booking?> getBooking(String bookingId) async {
    try {
      final response = await http
          .get(
            Uri.parse('$baseUrl/api/bookings/$bookingId'),
          )
          .timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final b = jsonDecode(response.body);
        return Booking(
          id: b['id']?.toString(),
          vehicleId: b['vehicleId'].toString(),
          vehicleBrand: b['vehicleBrand'] ?? '',
          vehicleModel: b['vehicleModel'] ?? '',
          vehicleOwnerId: b['vehicleOwnerId'] ?? '',
          vehicleOwnerName: b['vehicleOwnerName'] ?? '',
          renterId: b['renterId'] ?? '',
          renterName: b['renterName'] ?? '',
          renterEmail: b['renterEmail'] ?? '',
          startDate: DateTime.parse(b['startDate'].toString()),
          endDate: DateTime.parse(b['endDate'].toString()),
          numberOfDays: int.parse(b['numberOfDays'].toString()),
          totalPrice: double.parse(b['totalPrice'].toString()),
          status: bookingStatusFromString(b['status'] ?? 'pending'),
          notes: b['notes'],
          createdAt: DateTime.parse(b['createdAt'].toString()),
          updatedAt: b['updatedAt'] != null
              ? DateTime.parse(b['updatedAt'].toString())
              : null,
        );
      } else if (response.statusCode == 404) {
        return null;
      } else {
        throw Exception('Failed to load booking: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Error fetching booking: $e');
    }
  }
}
