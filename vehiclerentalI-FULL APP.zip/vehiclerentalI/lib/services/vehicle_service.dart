import 'package:http/http.dart' as http;
import 'dart:convert';
import '../models/vehicle.dart';

class VehicleService {
  // Change this to your actual PHP server URL
  static const String baseUrl = 'http://localhost:80/vehiclerental-api';

  /// Fetch all available vehicles from PHP backend
  static Future<List<Vehicle>> fetchVehicles() async {
    try {
      final response = await http
          .get(
            Uri.parse('$baseUrl/api/vehicles'),
          )
          .timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final List<dynamic> data = jsonDecode(response.body);
        return data
            .map((v) => Vehicle.fromJson({
                  'id': v['id'].toString(),
                  ...v,
                  'imageUrls': v['imageUrls'] is String
                      ? jsonDecode(v['imageUrls'] ?? '[]')
                      : (v['imageUrls'] ?? []),
                }))
            .where((vehicle) => vehicle.isAvailable)
            .toList();
      } else {
        throw Exception('Failed to load vehicles: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Error fetching vehicles: $e');
    }
  }

  /// Add a new vehicle to PHP backend
  static Future<String> addVehicle(Vehicle vehicle) async {
    try {
      final response = await http
          .post(
            Uri.parse('$baseUrl/api/vehicles'),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({
              'brand': vehicle.brand,
              'model': vehicle.model,
              'type': vehicle.type,
              'year': vehicle.year,
              'location': vehicle.location,
              'ownerId': vehicle.ownerId,
              'ownerName': vehicle.ownerName,
              'ownerEmail': vehicle.ownerEmail,
              'pricePerDay': vehicle.pricePerDay,
              'isAvailable': vehicle.isAvailable ? 1 : 0,
              'imageUrls': vehicle.imageUrls,
              'description': vehicle.description ?? '',
              'geoLat': vehicle.geoLocation?.latitude,
              'geoLng': vehicle.geoLocation?.longitude,
            }),
          )
          .timeout(const Duration(seconds: 10));

      if (response.statusCode == 201) {
        final data = jsonDecode(response.body);
        return data['id'].toString();
      } else {
        throw Exception('Failed to add vehicle: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Error adding vehicle: $e');
    }
  }

  /// Update a vehicle in PHP backend
  static Future<void> updateVehicle(Vehicle vehicle) async {
    if (vehicle.id == null)
      throw Exception('Vehicle ID is required for update');

    try {
      final response = await http
          .put(
            Uri.parse('$baseUrl/api/vehicles/${vehicle.id}'),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({
              'brand': vehicle.brand,
              'model': vehicle.model,
              'type': vehicle.type,
              'year': vehicle.year,
              'location': vehicle.location,
              'ownerId': vehicle.ownerId,
              'ownerName': vehicle.ownerName,
              'ownerEmail': vehicle.ownerEmail,
              'pricePerDay': vehicle.pricePerDay,
              'isAvailable': vehicle.isAvailable ? 1 : 0,
              'imageUrls': vehicle.imageUrls,
              'description': vehicle.description ?? '',
              'geoLat': vehicle.geoLocation?.latitude,
              'geoLng': vehicle.geoLocation?.longitude,
            }),
          )
          .timeout(const Duration(seconds: 10));

      if (response.statusCode != 200) {
        throw Exception('Failed to update vehicle: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Error updating vehicle: $e');
    }
  }

  /// Delete a vehicle from PHP backend
  static Future<void> deleteVehicle(String vehicleId) async {
    try {
      final response = await http
          .delete(
            Uri.parse('$baseUrl/api/vehicles/$vehicleId'),
          )
          .timeout(const Duration(seconds: 10));

      if (response.statusCode != 200) {
        throw Exception('Failed to delete vehicle: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Error deleting vehicle: $e');
    }
  }

  /// Get a single vehicle by ID
  static Future<Vehicle?> getVehicle(String vehicleId) async {
    try {
      final response = await http
          .get(
            Uri.parse('$baseUrl/api/vehicles/$vehicleId'),
          )
          .timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return Vehicle.fromJson({
          'id': data['id'].toString(),
          ...data,
          'imageUrls': data['imageUrls'] is String
              ? jsonDecode(data['imageUrls'] ?? '[]')
              : (data['imageUrls'] ?? []),
        });
      } else if (response.statusCode == 404) {
        return null;
      } else {
        throw Exception('Failed to load vehicle: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Error fetching vehicle: $e');
    }
  }

  /// Get vehicles by owner ID
  static Future<List<Vehicle>> getVehiclesByOwner(String ownerId) async {
    try {
      final response = await http
          .get(
            Uri.parse('$baseUrl/api/vehicles'),
          )
          .timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final List<dynamic> data = jsonDecode(response.body);
        return data
            .map((v) => Vehicle.fromJson({
                  'id': v['id'].toString(),
                  ...v,
                  'imageUrls': v['imageUrls'] is String
                      ? jsonDecode(v['imageUrls'] ?? '[]')
                      : (v['imageUrls'] ?? []),
                }))
            .where((vehicle) => vehicle.ownerId == ownerId)
            .toList();
      } else {
        throw Exception('Failed to load vehicles: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Error fetching vehicles: $e');
    }
  }
}
