enum BookingStatus {
  pending,
  approved,
  declined,
  cancelled,
  completed,
}

extension BookingStatusExtension on BookingStatus {
  String get value {
    switch (this) {
      case BookingStatus.pending:
        return 'pending';
      case BookingStatus.approved:
        return 'approved';
      case BookingStatus.declined:
        return 'declined';
      case BookingStatus.cancelled:
        return 'cancelled';
      case BookingStatus.completed:
        return 'completed';
    }
  }
}

BookingStatus bookingStatusFromString(String value) {
  switch (value) {
    case 'pending':
      return BookingStatus.pending;
    case 'approved':
      return BookingStatus.approved;
    case 'declined':
      return BookingStatus.declined;
    case 'cancelled':
      return BookingStatus.cancelled;
    case 'completed':
      return BookingStatus.completed;
    default:
      return BookingStatus.pending;
  }
}

class Booking {
  final String? id;
  final String vehicleId;
  final String vehicleBrand;
  final String vehicleModel;
  final String vehicleOwnerId;
  final String vehicleOwnerName;
  final String renterId;
  final String renterName;
  final String renterEmail;
  final DateTime startDate;
  final DateTime endDate;
  final int numberOfDays;
  final double totalPrice;
  final BookingStatus status;
  final String? notes;
  final DateTime createdAt;
  final DateTime? updatedAt;

  Booking({
    this.id,
    required this.vehicleId,
    required this.vehicleBrand,
    required this.vehicleModel,
    required this.vehicleOwnerId,
    required this.vehicleOwnerName,
    required this.renterId,
    required this.renterName,
    required this.renterEmail,
    required this.startDate,
    required this.endDate,
    required this.numberOfDays,
    required this.totalPrice,
    this.status = BookingStatus.pending,
    this.notes,
    required this.createdAt,
    this.updatedAt,
  });

  Map<String, dynamic> toFirestore() {
    return {
      'vehicleId': vehicleId,
      'vehicleBrand': vehicleBrand,
      'vehicleModel': vehicleModel,
      'vehicleOwnerId': vehicleOwnerId,
      'vehicleOwnerName': vehicleOwnerName,
      'renterId': renterId,
      'renterName': renterName,
      'renterEmail': renterEmail,
      'startDate': startDate.toIso8601String(),
      'endDate': endDate.toIso8601String(),
      'numberOfDays': numberOfDays,
      'totalPrice': totalPrice,
      'status': status.value,
      'notes': notes ?? '',
      'createdAt': createdAt.toIso8601String(),
      'updatedAt': updatedAt?.toIso8601String(),
    };
  }

  factory Booking.fromFirestore(String id, Map<String, dynamic> data) {
    return Booking(
      id: id,
      vehicleId: data['vehicleId'] ?? '',
      vehicleBrand: data['vehicleBrand'] ?? '',
      vehicleModel: data['vehicleModel'] ?? '',
      vehicleOwnerId: data['vehicleOwnerId'] ?? '',
      vehicleOwnerName: data['vehicleOwnerName'] ?? '',
      renterId: data['renterId'] ?? '',
      renterName: data['renterName'] ?? '',
      renterEmail: data['renterEmail'] ?? '',
      startDate:
          DateTime.parse(data['startDate'] ?? DateTime.now().toIso8601String()),
      endDate:
          DateTime.parse(data['endDate'] ?? DateTime.now().toIso8601String()),
      numberOfDays: data['numberOfDays'] ?? 0,
      totalPrice: (data['totalPrice'] ?? 0.0).toDouble(),
      status: bookingStatusFromString(data['status'] ?? 'pending'),
      notes: data['notes'],
      createdAt:
          DateTime.parse(data['createdAt'] ?? DateTime.now().toIso8601String()),
      updatedAt:
          data['updatedAt'] != null ? DateTime.parse(data['updatedAt']) : null,
    );
  }

  Booking copyWith({
    String? id,
    String? vehicleId,
    String? vehicleBrand,
    String? vehicleModel,
    String? vehicleOwnerId,
    String? vehicleOwnerName,
    String? renterId,
    String? renterName,
    String? renterEmail,
    DateTime? startDate,
    DateTime? endDate,
    int? numberOfDays,
    double? totalPrice,
    BookingStatus? status,
    String? notes,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return Booking(
      id: id ?? this.id,
      vehicleId: vehicleId ?? this.vehicleId,
      vehicleBrand: vehicleBrand ?? this.vehicleBrand,
      vehicleModel: vehicleModel ?? this.vehicleModel,
      vehicleOwnerId: vehicleOwnerId ?? this.vehicleOwnerId,
      vehicleOwnerName: vehicleOwnerName ?? this.vehicleOwnerName,
      renterId: renterId ?? this.renterId,
      renterName: renterName ?? this.renterName,
      renterEmail: renterEmail ?? this.renterEmail,
      startDate: startDate ?? this.startDate,
      endDate: endDate ?? this.endDate,
      numberOfDays: numberOfDays ?? this.numberOfDays,
      totalPrice: totalPrice ?? this.totalPrice,
      status: status ?? this.status,
      notes: notes ?? this.notes,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }

  bool overlapsWith(Booking other) {
    if (vehicleId != other.vehicleId) return false;
    if (status == BookingStatus.declined || status == BookingStatus.cancelled)
      return false;
    if (other.status == BookingStatus.declined ||
        other.status == BookingStatus.cancelled) return false;

    return (startDate.isBefore(other.endDate) ||
            startDate.isAtSameMomentAs(other.endDate)) &&
        (endDate.isAfter(other.startDate) ||
            endDate.isAtSameMomentAs(other.startDate));
  }
}
