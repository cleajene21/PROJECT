import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'firebase_options.dart';

import 'services/auth_service.dart';
import 'services/firestore_service.dart';
import 'screens/login.dart';
import 'screens/register.dart';
import 'screens/forgot_password.dart';
import 'screens/home_user.dart';
import 'screens/home_admin.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // Initialize Firebase for all platforms including web
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Vehicle Rental',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      debugShowCheckedModeBanner: false,
      routes: {
        '/register': (context) => const RegisterScreen(),
        '/login': (context) => const LoginScreen(),
        '/forgot': (context) => const ForgotPasswordScreen(),
      },
      home: const AuthWrapper(),
    );
  }
}

class AuthWrapper extends StatelessWidget {
  const AuthWrapper({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder(
      stream: AuthService().authStateChanges(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Scaffold(
            body: Center(child: CircularProgressIndicator()),
          );
        }
        if (!snapshot.hasData) return const LoginScreen();

        final user = snapshot.data as dynamic;

        if (user == null) return const LoginScreen();

        // Fetch role from Firestore and route accordingly
        return FutureBuilder<String>(
          future: FirestoreService().getRole(user.uid).timeout(
                const Duration(seconds: 5),
                onTimeout: () => 'user',
              ),
          builder: (context, roleSnap) {
            if (roleSnap.connectionState == ConnectionState.waiting)
              return const Scaffold(
                  body: Center(child: CircularProgressIndicator()));
            final role = roleSnap.data ?? 'user';
            if (role == 'admin' || role == 'owner') return const HomeAdmin();
            return const HomeUser();
          },
        );
      },
    );
  }
}
