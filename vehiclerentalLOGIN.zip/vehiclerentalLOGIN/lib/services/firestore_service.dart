import 'package:cloud_firestore/cloud_firestore.dart';

class FirestoreService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<void> createUserIfNotExists({required String uid, String? email, String? displayName, bool emailVerified = false}) async {
    final docRef = _firestore.collection('users').doc(uid);
    final snap = await docRef.get();
    if (!snap.exists) {
      await docRef.set({
        'email': email ?? '',
        'displayName': displayName ?? '',
        'role': 'user',
        'emailVerified': emailVerified,
        'createdAt': FieldValue.serverTimestamp(),
      });
    } else {
      // Update emailVerified flag if changed
      final data = snap.data();
      if (data != null && (data['emailVerified'] as bool?) != emailVerified) {
        await docRef.update({'emailVerified': emailVerified});
      }
    }
  }

  Future<String> getRole(String uid) async {
    final snap = await _firestore.collection('users').doc(uid).get();
    if (!snap.exists) return 'user';
    final data = snap.data();
    return (data?['role'] as String?) ?? 'user';
  }
}
