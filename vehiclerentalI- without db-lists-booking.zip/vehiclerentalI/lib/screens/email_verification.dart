import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../services/firestore_service.dart';
import 'home_user.dart';
import 'home_admin.dart';

class EmailVerificationScreen extends StatefulWidget {
  const EmailVerificationScreen({super.key});

  @override
  State<EmailVerificationScreen> createState() => _EmailVerificationScreenState();
}

class _EmailVerificationScreenState extends State<EmailVerificationScreen> {
  bool _checking = false;

  Future<void> _resend() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user != null && !user.emailVerified) {
      await user.sendEmailVerification();
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Verification email sent')));
    }
  }

  Future<void> _checkVerified() async {
    setState(() => _checking = true);
    final user = FirebaseAuth.instance.currentUser;
    await user?.reload();
    if (user != null && user.emailVerified) {
      if (!mounted) return;
      // Get user role and redirect to appropriate home screen
      final role = await FirestoreService().getRole(user.uid);
      if (!mounted) return;
      
      if (role == 'admin') {
        Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (_) => const HomeAdmin()),
        );
      } else {
        Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (_) => const HomeUser()),
        );
      }
    } else {
      setState(() => _checking = false);
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Email not verified yet')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Verify Email')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Text('A verification email was sent to your address. Please verify to continue.'),
          const SizedBox(height: 12),
          ElevatedButton(onPressed: _resend, child: const Text('Resend verification email')),
          const SizedBox(height: 8),
          ElevatedButton(onPressed: _checkVerified, child: _checking ? const CircularProgressIndicator() : const Text('I verified, check now')),
        ]),
      ),
    );
  }
}
