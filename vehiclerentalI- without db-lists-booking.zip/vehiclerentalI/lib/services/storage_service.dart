import 'dart:io';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:image_picker/image_picker.dart';

class StorageService {
  final FirebaseStorage _storage = FirebaseStorage.instance;
  final ImagePicker _picker = ImagePicker();

  Future<List<String>> uploadVehicleImages(String vehicleId, List<XFile> images) async {
    final List<String> downloadUrls = [];
    
    for (int i = 0; i < images.length; i++) {
      final file = File(images[i].path);
      final fileName = 'vehicles/$vehicleId/image_$i.jpg';
      final ref = _storage.ref().child(fileName);
      
      await ref.putFile(file);
      final url = await ref.getDownloadURL();
      downloadUrls.add(url);
    }
    
    return downloadUrls;
  }

  Future<String> uploadSingleImage(String path, String fileName) async {
    final file = File(path);
    final ref = _storage.ref().child(fileName);
    await ref.putFile(file);
    return await ref.getDownloadURL();
  }

  Future<void> deleteImage(String imageUrl) async {
    try {
      final ref = _storage.refFromURL(imageUrl);
      await ref.delete();
    } catch (e) {
      // Image might not exist, ignore error
    }
  }

  Future<void> deleteVehicleImages(String vehicleId) async {
    try {
      final listResult = await _storage.ref().child('vehicles/$vehicleId').listAll();
      for (var item in listResult.items) {
        await item.delete();
      }
    } catch (e) {
      // Folder might not exist, ignore error
    }
  }

  Future<List<XFile>> pickImages({int maxImages = 5}) async {
    final List<XFile> images = await _picker.pickMultiImage();
    if (images.length > maxImages) {
      return images.sublist(0, maxImages);
    }
    return images;
  }

  Future<XFile?> pickSingleImage() async {
    return await _picker.pickImage(source: ImageSource.gallery);
  }
}
