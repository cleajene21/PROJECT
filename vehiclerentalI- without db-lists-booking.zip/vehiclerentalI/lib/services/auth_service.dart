import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart' show kIsWeb, kDebugMode;
import 'dart:developer' as developer;

// Conditional import to avoid referencing google_sign_in on web (prevents compile issues)
import 'google_sign_nonweb.dart'
    if (dart.library.html) 'google_sign_web.dart' as gsign;

import 'firestore_service.dart';

class AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirestoreService _fs = FirestoreService();

  Stream<User?> authStateChanges() => _auth.authStateChanges();

  Future<UserCredential?> signInWithGoogle() async {
    try {
      if (kDebugMode) developer.log('[AuthService] Starting Google sign-in (kIsWeb=$kIsWeb)');
      UserCredential? result;
      if (kIsWeb) {
        final provider = GoogleAuthProvider();
        result = await _auth.signInWithPopup(provider);
      } else {
        final tokens = await gsign.signInGoogleNonWeb();
        if (tokens == null) {
          if (kDebugMode) developer.log('[AuthService] Google sign-in canceled by user (native).');
          return null;
        }

        final credential = GoogleAuthProvider.credential(
          accessToken: tokens['accessToken'],
          idToken: tokens['idToken'],
        );

        result = await _auth.signInWithCredential(credential);
      }
      if (kDebugMode) developer.log('[AuthService] signInWithGoogle result: user=${result.user!.uid}');

      // Ensure Firestore user document exists and emailVerified flag is set
      final user = result.user;
      if (user != null) {
        try {
          await _fs.createUserIfNotExists(
            uid: user.uid,
            email: user.email,
            displayName: user.displayName,
            emailVerified: user.emailVerified,
          );
        } catch (e) {
          // Firestore write failed - non-critical for sign-in
          if (kDebugMode) {
            developer.log('[AuthService] Failed to create/update Firestore user document: $e');
          }
        }
      }

      return result;
    } on FirebaseAuthException catch (e) {
      // Provide informative message
      throw Exception('FirebaseAuthException: ${e.code} - ${e.message}');
    } catch (e) {
      throw Exception('Sign-in failed: $e');
    }
  }

  Future<UserCredential> createUserWithEmail({required String email, required String password, String? displayName}) async {
    try {
      final cred = await _auth.createUserWithEmailAndPassword(email: email, password: password);
      final user = cred.user;
      if (user != null) {
        try {
          await user.updateDisplayName(displayName);
        } catch (e) {
          // Display name update is non-critical, continue
        }
        
        try {
          await user.sendEmailVerification();
        } catch (e) {
          // Email verification sending is non-critical, continue
        }
        
        // Try to create Firestore user document, but don't fail registration if this fails
        try {
          await _fs.createUserIfNotExists(uid: user.uid, email: email, displayName: displayName, emailVerified: user.emailVerified);
        } catch (e) {
          // Firestore write failed - likely due to security rules
          // Account is still created, but Firestore document may not exist yet
          // This can be fixed by updating Firestore security rules
          if (kDebugMode) {
            developer.log('[AuthService] Failed to create Firestore user document: $e');
          }
        }
      }

      return cred;
    } on FirebaseAuthException catch (e) {
      String errorMessage = 'Registration failed. ';
      switch (e.code) {
        case 'weak-password':
          errorMessage += 'The password is too weak.';
          break;
        case 'email-already-in-use':
          errorMessage += 'An account already exists for this email.';
          break;
        case 'invalid-email':
          errorMessage += 'Invalid email address.';
          break;
        default:
          errorMessage += '${e.message ?? e.code}';
      }
      throw Exception(errorMessage);
    } catch (e) {
      throw Exception('Registration failed: $e');
    }
  }

  Future<UserCredential> signInWithEmail({required String email, required String password}) async {
    try {
      final cred = await _auth.signInWithEmailAndPassword(email: email, password: password);
      final user = cred.user;
      if (user != null) {
        // Ensure user doc exists and emailVerified flag stored
        try {
          await _fs.createUserIfNotExists(uid: user.uid, email: user.email, displayName: user.displayName, emailVerified: user.emailVerified);
        } catch (e) {
          // Firestore write failed - non-critical for sign-in
          if (kDebugMode) {
            developer.log('[AuthService] Failed to create/update Firestore user document: $e');
          }
        }
      }
      return cred;
    } on FirebaseAuthException catch (e) {
      throw Exception('FirebaseAuthException: ${e.code} - ${e.message}');
    } catch (e) {
      throw Exception('Sign-in failed: $e');
    }
  }

  Future<void> sendPasswordReset(String email) async {
    await _auth.sendPasswordResetEmail(email: email);
  }

  Future<void> signOut() async {
    await _auth.signOut();
    await gsign.signOutGoogleNonWeb();
  }
}
