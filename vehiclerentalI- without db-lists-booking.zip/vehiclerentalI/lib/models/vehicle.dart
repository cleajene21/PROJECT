class Vehicle {
  final String? id;
  final String ownerId;
  final String ownerName;
  final String ownerEmail;
  final String brand;
  final String model;
  final String type; // e.g., Sedan, SUV, Motorcycle, etc.
  final String year;
  final double pricePerDay;
  final String? description;
  final List<String> imageUrls;
  final String location;
  final GeoLocation? geoLocation; // For mapping
  final bool isAvailable;
  final DateTime createdAt;
  final DateTime? updatedAt;

  Vehicle({
    this.id,
    required this.ownerId,
    required this.ownerName,
    required this.ownerEmail,
    required this.brand,
    required this.model,
    required this.type,
    required this.year,
    required this.pricePerDay,
    this.description,
    required this.imageUrls,
    required this.location,
    this.geoLocation,
    this.isAvailable = true,
    required this.createdAt,
    this.updatedAt,
  });

  Map<String, dynamic> toFirestore() {
    return {
      'ownerId': ownerId,
      'ownerName': ownerName,
      'ownerEmail': ownerEmail,
      'brand': brand,
      'model': model,
      'type': type,
      'year': year,
      'pricePerDay': pricePerDay,
      'description': description ?? '',
      'imageUrls': imageUrls,
      'location': location,
      'geoLocation': geoLocation?.toMap(),
      'isAvailable': isAvailable,
      'createdAt': createdAt.toIso8601String(),
      'updatedAt': updatedAt?.toIso8601String(),
    };
  }

  factory Vehicle.fromFirestore(String id, Map<String, dynamic> data) {
    return Vehicle(
      id: id,
      ownerId: data['ownerId'] ?? '',
      ownerName: data['ownerName'] ?? '',
      ownerEmail: data['ownerEmail'] ?? '',
      brand: data['brand'] ?? '',
      model: data['model'] ?? '',
      type: data['type'] ?? '',
      year: data['year'] ?? '',
      pricePerDay: (data['pricePerDay'] ?? 0.0).toDouble(),
      description: data['description'],
      imageUrls: List<String>.from(data['imageUrls'] ?? []),
      location: data['location'] ?? '',
      geoLocation: data['geoLocation'] != null
          ? GeoLocation.fromMap(data['geoLocation'])
          : null,
      isAvailable: data['isAvailable'] ?? true,
      createdAt: DateTime.parse(data['createdAt'] ?? DateTime.now().toIso8601String()),
      updatedAt: data['updatedAt'] != null ? DateTime.parse(data['updatedAt']) : null,
    );
  }

  Vehicle copyWith({
    String? id,
    String? ownerId,
    String? ownerName,
    String? ownerEmail,
    String? brand,
    String? model,
    String? type,
    String? year,
    double? pricePerDay,
    String? description,
    List<String>? imageUrls,
    String? location,
    GeoLocation? geoLocation,
    bool? isAvailable,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return Vehicle(
      id: id ?? this.id,
      ownerId: ownerId ?? this.ownerId,
      ownerName: ownerName ?? this.ownerName,
      ownerEmail: ownerEmail ?? this.ownerEmail,
      brand: brand ?? this.brand,
      model: model ?? this.model,
      type: type ?? this.type,
      year: year ?? this.year,
      pricePerDay: pricePerDay ?? this.pricePerDay,
      description: description ?? this.description,
      imageUrls: imageUrls ?? this.imageUrls,
      location: location ?? this.location,
      geoLocation: geoLocation ?? this.geoLocation,
      isAvailable: isAvailable ?? this.isAvailable,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }
}

class GeoLocation {
  final double latitude;
  final double longitude;

  GeoLocation({required this.latitude, required this.longitude});

  Map<String, dynamic> toMap() {
    return {
      'latitude': latitude,
      'longitude': longitude,
    };
  }

  factory GeoLocation.fromMap(Map<String, dynamic> map) {
    return GeoLocation(
      latitude: (map['latitude'] ?? 0.0).toDouble(),
      longitude: (map['longitude'] ?? 0.0).toDouble(),
    );
  }
}
