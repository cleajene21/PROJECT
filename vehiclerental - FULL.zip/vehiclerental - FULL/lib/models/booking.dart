import 'package:cloud_firestore/cloud_firestore.dart';

class Booking {
  final String id;
  final String vehicleId;
  final String renterUid;
  final String vehicleOwner;
  final DateTime? startDate;
  final DateTime? endDate;
  final String status; // pending, approved, declined, cancelled
  final DateTime? createdAt;

  Booking({required this.id, required this.vehicleId, required this.renterUid, required this.vehicleOwner, this.startDate, this.endDate, required this.status, this.createdAt});

  factory Booking.fromMap(String id, Map<String, dynamic> data) => Booking(
        id: id,
        vehicleId: data['vehicleId'] ?? '',
        renterUid: data['renterUid'] ?? '',
        vehicleOwner: data['vehicleOwner'] ?? '',
        startDate: data['startDate'] != null ? (data['startDate'] as Timestamp).toDate() : null,
        endDate: data['endDate'] != null ? (data['endDate'] as Timestamp).toDate() : null,
        status: data['status'] ?? 'pending',
        createdAt: data['createdAt'] != null ? (data['createdAt'] as Timestamp).toDate() : null,
      );

  Map<String, dynamic> toMap() => {
        'vehicleId': vehicleId,
        'renterUid': renterUid,
        'vehicleOwner': vehicleOwner,
        'startDate': startDate,
        'endDate': endDate,
        'status': status,
        'createdAt': createdAt,
      };
}