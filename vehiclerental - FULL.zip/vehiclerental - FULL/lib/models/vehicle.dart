class Vehicle {
  final String id;
  final String make;
  final String model;
  final String plate;
  final String status; // available, rented, maintenance
  final String createdBy;
  final String? imageUrl;
  final int? year;
  final int? seats;
  final double? pricePerDay;
  final String? description;
  final double? latitude;
  final double? longitude;

  Vehicle({required this.id, required this.make, required this.model, required this.plate, required this.status, required this.createdBy, this.imageUrl, this.year, this.seats, this.pricePerDay, this.description});

  factory Vehicle.fromMap(String id, Map<String, dynamic> data) => Vehicle(
        id: id,
        make: data['make'] ?? '',
        model: data['model'] ?? '',
        plate: data['plate'] ?? '',
        status: data['status'] ?? 'available',
        createdBy: data['createdBy'] ?? '',
        imageUrl: data['imageUrl'] as String?,
        year: (data['year'] is int) ? data['year'] as int : (data['year'] != null ? (data['year'] as num).toInt() : null),
        seats: (data['seats'] is int) ? data['seats'] as int : (data['seats'] != null ? (data['seats'] as num).toInt() : null),
        pricePerDay: data['price_per_day'] != null ? (data['price_per_day'] as num).toDouble() : null,
        description: data['description'] as String?,
        latitude: data['latitude'] != null ? (data['latitude'] as num).toDouble() : null,
        longitude: data['longitude'] != null ? (data['longitude'] as num).toDouble() : null,
      );

  Map<String, dynamic> toMap() => {
        'make': make,
        'model': model,
        'plate': plate,
        'status': status,
        'createdBy': createdBy,
        if (imageUrl != null) 'imageUrl': imageUrl,
        if (year != null) 'year': year,
        if (seats != null) 'seats': seats,
        if (pricePerDay != null) 'price_per_day': pricePerDay,
        if (description != null) 'description': description,
        if (latitude != null) 'latitude': latitude,
        if (longitude != null) 'longitude': longitude,
        'updatedAt': DateTime.now().toUtc(),
      };
}
