import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart' show kIsWeb, kDebugMode;
import 'dart:developer' as developer;

// Conditional import to avoid referencing google_sign_in on web (prevents compile issues)
import 'google_sign_nonweb.dart'
    if (dart.library.html) 'google_sign_web.dart' as gsign;

import 'firestore_service.dart';

class AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirestoreService _fs = FirestoreService();

  Stream<User?> authStateChanges() => _auth.authStateChanges();

  Future<UserCredential?> signInWithGoogle() async {
    try {
      if (kDebugMode) developer.log('[AuthService] Starting Google sign-in (kIsWeb=$kIsWeb)');
      UserCredential? result;
      if (kIsWeb) {
        final provider = GoogleAuthProvider();
        result = await _auth.signInWithPopup(provider);
      } else {
        final tokens = await gsign.signInGoogleNonWeb();
        if (tokens == null) {
          if (kDebugMode) developer.log('[AuthService] Google sign-in canceled by user (native).');
          return null;
        }

        final credential = GoogleAuthProvider.credential(
          accessToken: tokens['accessToken'],
          idToken: tokens['idToken'],
        );

        result = await _auth.signInWithCredential(credential);
      }
      if (kDebugMode) developer.log('[AuthService] signInWithGoogle result: user=${result?.user?.uid}');

      // Ensure Firestore user document exists and emailVerified flag is set
      final user = (result == null) ? _auth.currentUser : result.user;
      if (user != null) {
        await _fs.createUserIfNotExists(
          uid: user.uid,
          email: user.email,
          displayName: user.displayName,
          emailVerified: user.emailVerified,
        );
      }

      return result;
    } on FirebaseAuthException catch (e) {
      // Provide informative message
      throw Exception('FirebaseAuthException: ${e.code} - ${e.message}');
    } catch (e) {
      throw Exception('Sign-in failed: $e');
    }
  }

  Future<UserCredential> createUserWithEmail({required String email, required String password, String? displayName}) async {
    try {
      final cred = await _auth.createUserWithEmailAndPassword(email: email, password: password);
      final user = cred.user;
      if (user != null) {
        await user.updateDisplayName(displayName);
        await user.sendEmailVerification();
        await _fs.createUserIfNotExists(uid: user.uid, email: email, displayName: displayName, emailVerified: user.emailVerified);
      }

      return cred;
    } on FirebaseAuthException catch (e) {
      throw Exception('FirebaseAuthException: ${e.code} - ${e.message}');
    }
  }

  Future<UserCredential> signInWithEmail({required String email, required String password}) async {
    try {
      final cred = await _auth.signInWithEmailAndPassword(email: email, password: password);
      final user = cred.user;
      if (user != null) {
        // Ensure user doc exists and emailVerified flag stored
        await _fs.createUserIfNotExists(uid: user.uid, email: user.email, displayName: user.displayName, emailVerified: user.emailVerified);
      }
      return cred;
    } on FirebaseAuthException catch (e) {
      throw Exception('FirebaseAuthException: ${e.code} - ${e.message}');
    } catch (e) {
      throw Exception('Sign-in failed: $e');
    }
  }

  Future<void> sendPasswordReset(String email) async {
    await _auth.sendPasswordResetEmail(email: email);
  }

  Future<void> signOut() async {
    await _auth.signOut();
    await gsign.signOutGoogleNonWeb();
  }
}
