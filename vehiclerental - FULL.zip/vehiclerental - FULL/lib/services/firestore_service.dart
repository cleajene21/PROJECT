import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class FirestoreService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<void> createUserIfNotExists({required String uid, String? email, String? displayName, bool emailVerified = false}) async {
    final docRef = _firestore.collection('users').doc(uid);
    final snap = await docRef.get();
    if (!snap.exists) {
      await docRef.set({
        'email': email ?? '',
        'displayName': displayName ?? '',
        'role': 'user',
        'emailVerified': emailVerified,
        'createdAt': FieldValue.serverTimestamp(),
      });
    } else {
      // Update emailVerified flag if changed
      final data = snap.data();
      if (data != null && (data['emailVerified'] as bool?) != emailVerified) {
        await docRef.update({'emailVerified': emailVerified});
      }
    }
  }

  Future<String> getRole(String uid) async {
    final snap = await _firestore.collection('users').doc(uid).get();
    if (!snap.exists) return 'user';
    final data = snap.data();
    return (data?['role'] as String?) ?? 'user';
  }

  // Vehicles CRUD
  Stream<List<Map<String, dynamic>>> streamVehicles() {
    return _firestore.collection('vehicles').orderBy('createdAt', descending: true).snapshots().map((snap) => snap.docs.map((d) => {'id': d.id, ...d.data()}).toList());
  }

  Future<void> addVehicle(Map<String, dynamic> data) async {
    final enriched = Map<String, dynamic>.from(data);
    enriched.putIfAbsent('createdAt', () => FieldValue.serverTimestamp());
    // Ensure owner is set if available from auth
    try {
      final uid = FirebaseAuth.instance.currentUser?.uid;
      if (uid != null && !(enriched.containsKey('createdBy') && enriched['createdBy'] != '')) {
        enriched['createdBy'] = uid;
      }
    } catch (_) {}
    await _firestore.collection('vehicles').add(enriched);
  }

  Future<void> updateVehicle(String id, Map<String, dynamic> data) async {
    await _firestore.collection('vehicles').doc(id).update({...data, 'updatedAt': FieldValue.serverTimestamp()});
  }

  Future<void> deleteVehicle(String id) async {
    await _firestore.collection('vehicles').doc(id).delete();
  }

  // Bookings
  Future<void> createBooking(String vehicleId, Map<String, dynamic> data) async {
    final now = FieldValue.serverTimestamp();
    await _firestore.collection('vehicles').doc(vehicleId).collection('bookings').add({...data, 'status': 'pending', 'createdAt': now});
  }

  Stream<List<Map<String, dynamic>>> streamBookingsForOwner(String ownerUid) {
    // returns bookings for vehicles owned by ownerUid
    return _firestore
        .collectionGroup('bookings')
        .where('vehicleOwner', isEqualTo: ownerUid)
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((snap) => snap.docs.map((d) => {'id': d.id, 'path': d.reference.path, ...d.data()}).toList());
  }

  Stream<List<Map<String, dynamic>>> streamBookingsForRenter(String renterUid) {
    return _firestore
        .collectionGroup('bookings')
        .where('renterUid', isEqualTo: renterUid)
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((snap) => snap.docs.map((d) => {'id': d.id, 'path': d.reference.path, ...d.data()}).toList());
  }

  Future<void> updateBookingStatus(String bookingPath, String status) async {
    await _firestore.doc(bookingPath).update({'status': status, 'updatedAt': FieldValue.serverTimestamp()});
  }
}
