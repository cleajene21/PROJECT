import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:firebase_auth/firebase_auth.dart';

class ApiService {
  // Set API_URL at build time or uses default localhost
  static final _baseUrl = const String.fromEnvironment('API_URL', defaultValue: 'http://localhost:8080');

  Future<List<Map<String, dynamic>>> fetchVehicles() async {
    final token = await FirebaseAuth.instance.currentUser?.getIdToken();
    final res = await http.get(Uri.parse('$_baseUrl/vehicles'), headers: {
      if (token != null) 'Authorization': 'Bearer $token',
    });

    if (res.statusCode == 200) {
      final data = jsonDecode(res.body) as List;
      return data.map((e) => Map<String, dynamic>.from(e)).toList();
    }

    throw Exception('Failed to fetch vehicles: ${res.statusCode} ${res.body}');
  }
}