// Web stub - functions return null or do nothing to avoid referencing google_sign_in package on web

Future<Map<String, String?>?> signInGoogleNonWeb() async {
  return null;
}

Future<void> signOutGoogleNonWeb() async {
  return;
}
