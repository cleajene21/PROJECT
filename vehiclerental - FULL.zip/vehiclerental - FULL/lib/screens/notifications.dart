import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class NotificationsScreen extends StatelessWidget {
  const NotificationsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final uid = FirebaseAuth.instance.currentUser?.uid ?? '';
    return Scaffold(
      appBar: AppBar(title: const Text('Notifications')),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance.collection('notifications').where('to', isEqualTo: uid).orderBy('createdAt', descending: true).snapshots(),
        builder: (context, snap) {
          if (snap.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
          final docs = snap.data?.docs ?? [];
          if (docs.isEmpty) return const Center(child: Text('No notifications'));
          return ListView(
            children: docs.map((d) {
              final data = d.data() as Map<String, dynamic>;
              return ListTile(
                title: Text(data['type'] ?? ''),
                subtitle: Text('Booking ${data['bookingId'] ?? ''} - ${data['status'] ?? ''}'),
                trailing: data['read'] == true ? null : const Icon(Icons.fiber_new, color: Colors.red),
                onTap: () async {
                  await d.reference.update({'read': true});
                },
              );
            }).toList(),
          );
        },
      ),
    );
  }
}