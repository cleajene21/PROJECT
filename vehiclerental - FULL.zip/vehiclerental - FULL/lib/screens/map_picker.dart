import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:geolocator/geolocator.dart';

class MapPicker extends StatefulWidget {
  final LatLng? initial;
  const MapPicker({super.key, this.initial});

  @override
  State<MapPicker> createState() => _MapPickerState();
}

class _MapPickerState extends State<MapPicker> {
  late LatLng _pos;

  @override
  void initState() {
    super.initState();
    _pos = widget.initial ?? LatLng(14.5995, 120.9842); // default Manila
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Pick location'), actions: [IconButton(icon: const Icon(Icons.check), onPressed: () => Navigator.of(context).pop(_pos))]),
      body: FlutterMap(
        options: MapOptions(center: _pos, zoom: 13.0, onTap: (tap, p) => setState(() => _pos = p)),
        children: [
          TileLayer(urlTemplate: 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', subdomains: const ['a', 'b', 'c']),
          MarkerLayer(markers: [Marker(point: _pos, width: 80, height: 80, builder: (ctx) => const Icon(Icons.location_on, size: 40, color: Colors.red))]),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(label: const Text('Use Current'), icon: const Icon(Icons.my_location), onPressed: () async {
        // attempt to get current location via Geolocator
        try {
          final loc = await Geolocator.getCurrentPosition();
          setState(() => _pos = LatLng(loc.latitude, loc.longitude));
        } catch (e) {
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Unable to get current location')));
        }
      }),
    );
  }
}