import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:latlong2/latlong.dart';
import 'map_picker.dart';
import '../services/firestore_service.dart';
import '../models/vehicle.dart';

class VehicleForm extends StatefulWidget {
  final Vehicle? vehicle;
  const VehicleForm({super.key, this.vehicle});

  @override
  State<VehicleForm> createState() => _VehicleFormState();
}

class _VehicleFormState extends State<VehicleForm> {
  final _formKey = GlobalKey<FormState>();
  final _makeCtrl = TextEditingController();
  final _modelCtrl = TextEditingController();
  final _plateCtrl = TextEditingController();
  final _yearCtrl = TextEditingController();
  final _seatsCtrl = TextEditingController();
  final _priceCtrl = TextEditingController();
  final _descriptionCtrl = TextEditingController();
  String _status = 'available';
  bool _loading = false;
  XFile? _pickedImage;
  String? _uploadedImageUrl;
  double? _latitude;
  double? _longitude;

  @override
  void initState() {
    super.initState();
    if (widget.vehicle != null) {
      _makeCtrl.text = widget.vehicle!.make;
      _modelCtrl.text = widget.vehicle!.model;
      _plateCtrl.text = widget.vehicle!.plate;
      _status = widget.vehicle!.status;
      _yearCtrl.text = widget.vehicle!.year?.toString() ?? '';
      _seatsCtrl.text = widget.vehicle!.seats?.toString() ?? '';
      _priceCtrl.text = widget.vehicle!.pricePerDay?.toString() ?? '';
      _descriptionCtrl.text = widget.vehicle!.description ?? '';
      _uploadedImageUrl = widget.vehicle!.imageUrl;
    }
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _loading = true);
    final data = {
      'make': _makeCtrl.text.trim(),
      'model': _modelCtrl.text.trim(),
      'plate': _plateCtrl.text.trim(),
      'status': _status,
      'year': int.tryParse(_yearCtrl.text.trim()),
      'seats': int.tryParse(_seatsCtrl.text.trim()),
      'price_per_day': double.tryParse(_priceCtrl.text.trim()),
      'description': _descriptionCtrl.text.trim(),
    };

    // if we picked an image, upload it first
    if (_pickedImage != null) {
      final fname = '${DateTime.now().millisecondsSinceEpoch}_${_pickedImage!.name}';
      final ref = FirebaseStorage.instance.ref().child('vehicles/$fname');
      final bytes = await _pickedImage!.readAsBytes();
      await ref.putData(bytes);
      final url = await ref.getDownloadURL();
      data['imageUrl'] = url;
    } else if (_uploadedImageUrl != null) {
      data['imageUrl'] = _uploadedImageUrl;
    }

    // if location chosen, include
    if (_latitude != null && _longitude != null) {
      data['latitude'] = _latitude;
      data['longitude'] = _longitude;
    }
    try {
      if (widget.vehicle == null) {
        await FirestoreService().addVehicle(data);
      } else {
        await FirestoreService().updateVehicle(widget.vehicle!.id, data);
      }
      if (mounted) Navigator.of(context).pop();
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error: $e')));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.vehicle == null ? 'Add Vehicle' : 'Edit Vehicle')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(children: [
            TextFormField(controller: _makeCtrl, decoration: const InputDecoration(labelText: 'Make'), validator: (v) => v != null && v.isNotEmpty ? null : 'Required'),
            TextFormField(controller: _modelCtrl, decoration: const InputDecoration(labelText: 'Model'), validator: (v) => v != null && v.isNotEmpty ? null : 'Required'),
            TextFormField(controller: _plateCtrl, decoration: const InputDecoration(labelText: 'Plate'), validator: (v) => v != null && v.isNotEmpty ? null : 'Required'),
            TextFormField(controller: _yearCtrl, decoration: const InputDecoration(labelText: 'Year'), keyboardType: TextInputType.number),
            TextFormField(controller: _seatsCtrl, decoration: const InputDecoration(labelText: 'Seats'), keyboardType: TextInputType.number),
            TextFormField(controller: _priceCtrl, decoration: const InputDecoration(labelText: 'Price per day'), keyboardType: TextInputType.number),
            TextFormField(controller: _descriptionCtrl, decoration: const InputDecoration(labelText: 'Description'), maxLines: 3),
            DropdownButtonFormField(value: _status, items: const [DropdownMenuItem(value: 'available', child: Text('Available')), DropdownMenuItem(value: 'rented', child: Text('Rented')), DropdownMenuItem(value: 'maintenance', child: Text('Maintenance'))], onChanged: (v) => setState(() => _status = v as String)),
            const SizedBox(height: 12),
            Row(children: [
              _uploadedImageUrl != null ? Image.network(_uploadedImageUrl!, width: 80, height: 80, fit: BoxFit.cover) : const SizedBox(width: 80, height: 80, child: Center(child: Text('No image'))),
              const SizedBox(width: 12),
              ElevatedButton(onPressed: () async {
                final p = await ImagePicker().pickImage(source: ImageSource.gallery, maxWidth: 1200, maxHeight: 800);
                if (p != null) setState(() => _pickedImage = p);
              }, child: const Text('Choose Image')),
            ]),
            const SizedBox(height: 8),
            Row(children: [
              Expanded(child: Text(_latitude != null && _longitude != null ? 'Location: ${_latitude!.toStringAsFixed(5)}, ${_longitude!.toStringAsFixed(5)}' : 'No location selected')),
              ElevatedButton(onPressed: () async {
                final res = await Navigator.of(context).push(MaterialPageRoute(builder: (_) => const MapPicker()));
                if (res != null && res is LatLng) setState(() { _latitude = res.latitude; _longitude = res.longitude; });
              }, child: const Text('Pick Location')),
            ]),
            const SizedBox(height: 12),
            _loading ? const CircularProgressIndicator() : ElevatedButton(onPressed: _save, child: const Text('Save')),
          ]),
        ),
      ),
    );
  }
}
