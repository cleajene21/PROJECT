import 'package:flutter/material.dart';
import '../services/firestore_service.dart';
import '../models/vehicle.dart';

class VehiclesList extends StatelessWidget {
  const VehiclesList({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Vehicles')),
      body: StreamBuilder<List<Map<String, dynamic>>>(
        stream: FirestoreService().streamVehicles(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
          final list = snapshot.data ?? [];
          if (list.isEmpty) return const Center(child: Text('No vehicles yet'));
          return ListView.builder(
            itemCount: list.length,
            itemBuilder: (context, i) {
              final doc = list[i];
              final vehicle = Vehicle.fromMap(doc['id'], doc);
              return ListTile(
                title: Text('${vehicle.make} ${vehicle.model}'),
                subtitle: Text('${vehicle.plate} • ${vehicle.status}'),
                onTap: () => Navigator.of(context).pushNamed('/vehicle_detail', arguments: vehicle),
              );
            },
          );
        },
      ),
      floatingActionButton: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          FloatingActionButton(
            heroTag: 'map',
            onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const VehiclesMap())),
            child: const Icon(Icons.map),
          ),
          const SizedBox(height: 12),
          FloatingActionButton(
            heroTag: 'add',
            onPressed: () => Navigator.of(context).pushNamed('/vehicle_create'),
            child: const Icon(Icons.add),
          ),
        ],
      ),
    );
  }
}
