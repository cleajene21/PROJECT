import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../services/auth_service.dart';

class HomeAdmin extends StatelessWidget {
  const HomeAdmin({super.key});

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    return Scaffold(
      appBar: AppBar(title: const Text('Admin Home')),
      drawer: Drawer(
        child: ListView(padding: EdgeInsets.zero, children: [
          UserAccountsDrawerHeader(accountName: Text(user?.displayName ?? ''), accountEmail: Text(user?.email ?? '')),
          ListTile(leading: const Icon(Icons.directions_car), title: const Text('Vehicles'), onTap: () => Navigator.of(context).pushNamed('/vehicles')),
          ListTile(leading: const Icon(Icons.group), title: const Text('Manage Users'), onTap: () {}),
          const Divider(),
          ListTile(leading: const Icon(Icons.logout), title: const Text('Sign out'), onTap: () => AuthService().signOut()),
        ]),
      ),
      body: Center(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Text('Admin: ${user?.displayName ?? user?.email ?? 'Admin'}'),
          const SizedBox(height: 12),
          ElevatedButton(onPressed: () => Navigator.of(context).pushNamed('/vehicles'), child: const Text('Manage Vehicles')),
        ]),
      ),
    );
  }
}
