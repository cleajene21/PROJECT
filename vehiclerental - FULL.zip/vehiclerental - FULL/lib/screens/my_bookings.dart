import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../services/firestore_service.dart';

class MyBookings extends StatelessWidget {
  const MyBookings({super.key});

  @override
  Widget build(BuildContext context) {
    final uid = FirebaseAuth.instance.currentUser?.uid ?? '';
    return Scaffold(
      appBar: AppBar(title: const Text('My Bookings')),
      body: StreamBuilder<List<Map<String, dynamic>>>(
        stream: FirestoreService().streamBookingsForRenter(uid),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
          final items = snapshot.data ?? [];
          if (items.isEmpty) return const Center(child: Text('No bookings'));
          return ListView.builder(
            itemCount: items.length,
            itemBuilder: (context, i) {
              final b = items[i];
              final start = b['startDate'] != null ? (b['startDate'] as Timestamp).toDate() : null;
              final end = b['endDate'] != null ? (b['endDate'] as Timestamp).toDate() : null;
              return ListTile(
                title: Text('Vehicle: ${b['vehicleId']}'),
                subtitle: Text('From ${start?.toLocal().toString().split(' ')[0] ?? '-'} to ${end?.toLocal().toString().split(' ')[0] ?? '-'}\nStatus: ${b['status']}'),
                isThreeLine: true,
                trailing: b['status'] == 'pending'
                    ? IconButton(icon: const Icon(Icons.cancel, color: Colors.red), onPressed: () async => await FirestoreService().updateBookingStatus(b['path'], 'cancelled'))
                    : null,
              );
            },
          );
        },
      ),
    );
  }
}