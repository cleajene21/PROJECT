import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:geolocator/geolocator.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../services/firestore_service.dart';
import '../models/vehicle.dart';
import '../services/geoutils.dart';

class VehiclesMap extends StatefulWidget {
  const VehiclesMap({super.key});

  @override
  State<VehiclesMap> createState() => _VehiclesMapState();
}

class _VehiclesMapState extends State<VehiclesMap> {
  double _radiusMeters = 10000; // 10km
  LatLng? _center;

  @override
  void initState() {
    super.initState();
    // optionally use current location
    Geolocator.getCurrentPosition().then((pos) {
      setState(() => _center = LatLng(pos.latitude, pos.longitude));
    }).catchError((_) {});
  }

  @override
  Widget build(BuildContext context) {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    return Scaffold(
      appBar: AppBar(title: const Text('Map')),
      body: Column(children: [
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: Row(children: [
            const Text('Radius:'),
            Expanded(child: Slider(min: 1000, max: 50000, value: _radiusMeters, onChanged: (v) => setState(() => _radiusMeters = v))),
            Text('${(_radiusMeters/1000).toStringAsFixed(1)} km')
          ]),
        ),
        Expanded(
          child: StreamBuilder<List<Map<String, dynamic>>>(
            stream: FirestoreService().streamVehicles(),
            builder: (context, snap) {
              if (snap.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
              final docs = snap.data ?? [];
              final vehicles = docs.map((d) => Vehicle.fromMap(d['id'], d)).where((v) => v.latitude != null && v.longitude != null).toList();
              final center = _center ?? (vehicles.isNotEmpty ? LatLng(vehicles.first.latitude!, vehicles.first.longitude!) : LatLng(14.5995, 120.9842));
              final filtered = _center == null ? vehicles : vehicles.where((v) => GeoUtils.distanceInMeters(_center!.latitude, _center!.longitude, v.latitude!, v.longitude!) <= _radiusMeters).toList();

              return FlutterMap(
                options: MapOptions(center: center, zoom: 12.0),
                children: [
                  TileLayer(urlTemplate: 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', subdomains: const ['a', 'b', 'c']),
                  MarkerLayer(markers: filtered.map((v) => Marker(point: LatLng(v.latitude!, v.longitude!), width: 80, height: 80, builder: (ctx) => GestureDetector(onTap: () => _showVehicleBottomSheet(v), child: const Icon(Icons.location_on, size: 40, color: Colors.red)))).toList()),
                ],
              );
            },
          ),
        ),
      ]),
    );
  }

  void _showVehicleBottomSheet(Vehicle v) {
    showModalBottomSheet(context: context, builder: (c) => Padding(padding: const EdgeInsets.all(16.0), child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [Text('${v.make} ${v.model}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)), if (v.imageUrl != null) Image.network(v.imageUrl!), Text('Price: ${v.pricePerDay ?? '-'}'), const SizedBox(height: 8), ElevatedButton(onPressed: () => Navigator.of(context).pushNamed('/vehicle_detail', arguments: v), child: const Text('View Details'))])));
  }
}