import 'package:flutter/material.dart';
import '../models/vehicle.dart';
import '../services/firestore_service.dart';
import 'booking_form.dart';
import 'vehicle_form.dart';

class VehicleDetail extends StatelessWidget {
  const VehicleDetail({super.key, required this.vehicle});
  final Vehicle vehicle;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('${vehicle.make} ${vehicle.model}')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Plate: ${vehicle.plate}'),
          const SizedBox(height: 8),
          Text('Status: ${vehicle.status}'),
          const SizedBox(height: 16),
          Row(children: [
            ElevatedButton(onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => VehicleForm(vehicle: vehicle))), child: const Text('Edit')),
            const SizedBox(width: 12),
            ElevatedButton(
              onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => BookingForm(vehicle: vehicle))),
              child: const Text('Request Booking'),
            ),
            const SizedBox(width: 12),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
              onPressed: () async {
                final ok = await showDialog<bool>(context: context, builder: (c) => AlertDialog(title: const Text('Confirm'), content: const Text('Delete this vehicle?'), actions: [TextButton(onPressed: () => Navigator.of(c).pop(false), child: const Text('Cancel')), TextButton(onPressed: () => Navigator.of(c).pop(true), child: const Text('Delete'))]));
                if (ok == true) {
                  await FirestoreService().deleteVehicle(vehicle.id);
                  if (context.mounted) Navigator.of(context).pop();
                }
              },
              child: const Text('Delete'),
            ),
          ])
        ]),
      ),
    );
  }
}
