import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../services/auth_service.dart';
import '../services/firestore_service.dart';
import '../services/api_service.dart';
import 'notifications.dart';

class HomeUser extends StatelessWidget {
  const HomeUser({super.key});

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    return Scaffold(
      appBar: AppBar(title: const Text('User Home')),
      drawer: Drawer(
        child: FutureBuilder<String>(
          future: user != null ? FirestoreService().getRole(user.uid) : Future.value('guest'),
          builder: (context, snapshot) {
            final role = snapshot.data ?? 'user';
            return ListView(padding: EdgeInsets.zero, children: [
              UserAccountsDrawerHeader(accountName: Text(user?.displayName ?? ''), accountEmail: Text(user?.email ?? '')),
              ListTile(
                leading: const Icon(Icons.directions_car),
                title: const Text('Vehicles'),
                onTap: () {
                  Navigator.of(context).pop();
                  Navigator.of(context).pushNamed('/vehicles');
                },
              ),
              ListTile(
                leading: const Icon(Icons.notifications),
                title: const Text('Notifications'),
                onTap: () {
                  Navigator.of(context).pop();
                  Navigator.of(context).push(MaterialPageRoute(builder: (_) => const NotificationsScreen()));
                },
              ),
              ListTile(
                leading: const Icon(Icons.book),
                title: const Text('My Bookings'),
                onTap: () {
                  Navigator.of(context).pop();
                  Navigator.of(context).pushNamed('/my_bookings');
                },
              ),
              if (role == 'admin')
                ListTile(
                  leading: const Icon(Icons.list),
                  title: const Text('Bookings (owner)'),
                  onTap: () {
                    Navigator.of(context).pop();
                    Navigator.of(context).pushNamed('/owner_bookings');
                  },
                ),
              if (role == 'admin')
                ListTile(
                  leading: const Icon(Icons.add),
                  title: const Text('Add Vehicle'),
                  onTap: () {
                    Navigator.of(context).pop();
                    Navigator.of(context).pushNamed('/vehicle_create');
                  },
                ),
              ListTile(leading: const Icon(Icons.person), title: const Text('Profile'), onTap: () {}),
              const Divider(),
              ListTile(
                leading: const Icon(Icons.logout),
                title: const Text('Sign out'),
                onTap: () async {
                  Navigator.of(context).pop();
                  await AuthService().signOut();
                },
              ),
            ]);
          },
        ),
      ),
      body: Center(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Text('Welcome, ${user?.displayName ?? user?.email ?? 'User'}'),
          const SizedBox(height: 12),
          ElevatedButton(onPressed: () => Navigator.of(context).pushNamed('/vehicles'), child: const Text('Manage Vehicles')),
          const SizedBox(height: 8),
          FutureBuilder<String>(
            future: user != null ? FirestoreService().getRole(user.uid) : Future.value('guest'),
            builder: (context, snapshot) {
              final role = snapshot.data ?? 'user';
              if (role == 'admin') {
                return ElevatedButton(onPressed: () => Navigator.of(context).pushNamed('/vehicle_create'), child: const Text('Create Vehicle'));
              }
              return const SizedBox.shrink();
            },
          ),
          const SizedBox(height: 8),
          ElevatedButton(
            onPressed: () async {
              try {
                final vehicles = await ApiService().fetchVehicles();
                if (!context.mounted) return;
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Fetched ${vehicles.length} vehicles from API')));
              } catch (e) {
                if (!context.mounted) return;
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('API fetch failed: $e')));
              }
            },
            child: const Text('Fetch Vehicles (API)'),
          ),
        ]),
      ),
    );
  }
}
