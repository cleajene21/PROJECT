import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/vehicle.dart';
import '../services/firestore_service.dart';

class BookingForm extends StatefulWidget {
  const BookingForm({super.key, required this.vehicle});
  final Vehicle vehicle;

  @override
  State<BookingForm> createState() => _BookingFormState();
}

class _BookingFormState extends State<BookingForm> {
  DateTime? _startDate;
  DateTime? _endDate;
  bool _submitting = false;

  Future<void> _pickStart() async {
    final now = DateTime.now();
    final picked = await showDatePicker(context: context, initialDate: now, firstDate: now, lastDate: DateTime(now.year + 2));
    if (picked != null) setState(() => _startDate = picked);
  }

  Future<void> _pickEnd() async {
    final now = DateTime.now();
    final picked = await showDatePicker(context: context, initialDate: _startDate ?? now, firstDate: _startDate ?? now, lastDate: DateTime(now.year + 2));
    if (picked != null) setState(() => _endDate = picked);
  }

  Future<void> _submit() async {
    if (_startDate == null || _endDate == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Please choose start and end dates')));
      return;
    }
    setState(() => _submitting = true);
    try {
      final uid = FirebaseAuth.instance.currentUser?.uid ?? '';
      await FirestoreService().createBooking(widget.vehicle.id, {
        'vehicleId': widget.vehicle.id,
        'renterUid': uid,
        'vehicleOwner': widget.vehicle.createdBy,
        'startDate': Timestamp.fromDate(_startDate!),
        'endDate': Timestamp.fromDate(_endDate!),
      });
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Booking requested')));
      Navigator.of(context).pop();
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Failed to book: $e')));
    } finally {
      if (mounted) setState(() => _submitting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Request Booking')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Vehicle: ${widget.vehicle.make} ${widget.vehicle.model}'),
          const SizedBox(height: 12),
          ListTile(title: const Text('Start date'), subtitle: Text(_startDate?.toLocal().toString().split(' ')[0] ?? 'Not set'), trailing: IconButton(icon: const Icon(Icons.calendar_today), onPressed: _pickStart)),
          ListTile(title: const Text('End date'), subtitle: Text(_endDate?.toLocal().toString().split(' ')[0] ?? 'Not set'), trailing: IconButton(icon: const Icon(Icons.calendar_today), onPressed: _pickEnd)),
          const SizedBox(height: 20),
          ElevatedButton(onPressed: _submitting ? null : _submit, child: Text(_submitting ? 'Submitting...' : 'Request Booking'))
        ]),
      ),
    );
  }
}