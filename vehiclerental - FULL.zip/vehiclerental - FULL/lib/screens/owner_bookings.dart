import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../services/firestore_service.dart';

class OwnerBookings extends StatelessWidget {
  const OwnerBookings({super.key});

  @override
  Widget build(BuildContext context) {
    final uid = FirebaseAuth.instance.currentUser?.uid ?? '';
    return Scaffold(
      appBar: AppBar(title: const Text('Bookings for your vehicles')),
      body: StreamBuilder<List<Map<String, dynamic>>>(
        stream: FirestoreService().streamBookingsForOwner(uid),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
          final items = snapshot.data ?? [];
          if (items.isEmpty) return const Center(child: Text('No booking requests'));
          return ListView.builder(
            itemCount: items.length,
            itemBuilder: (context, i) {
              final b = items[i];
              final start = b['startDate'] != null ? (b['startDate'] as Timestamp).toDate() : null;
              final end = b['endDate'] != null ? (b['endDate'] as Timestamp).toDate() : null;
              return ListTile(
                title: Text('${b['vehicleId']} (${b['renterUid']})'),
                subtitle: Text('From ${start?.toLocal().toString().split(' ')[0] ?? '-'} to ${end?.toLocal().toString().split(' ')[0] ?? '-'}\nStatus: ${b['status']}'),
                isThreeLine: true,
                trailing: b['status'] == 'pending'
                    ? Row(mainAxisSize: MainAxisSize.min, children: [
                        IconButton(icon: const Icon(Icons.check, color: Colors.green), onPressed: () async => await FirestoreService().updateBookingStatus(b['path'], 'approved')),
                        IconButton(icon: const Icon(Icons.close, color: Colors.red), onPressed: () async => await FirestoreService().updateBookingStatus(b['path'], 'declined')),
                      ])
                    : null,
              );
            },
          );
        },
      ),
    );
  }
}