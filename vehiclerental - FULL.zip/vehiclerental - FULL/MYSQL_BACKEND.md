MySQL Backend & Firestore→MySQL Sync

Overview
- The repository contains a basic Node.js Express API (`server/`) that serves vehicle data from a MySQL database.
- A Cloud Function (`server/functions/syncVehicle`) listens for Firestore `vehicles/{id}` writes and mirrors create/update/delete operations to MySQL.

Quick setup
1. Create the database and tables:
   - `mysql -u root -p` then `CREATE DATABASE vehiclerental;` and then run `mysql -u user -p vehiclerental < server/sql/001_create_vehicles.sql`.
2. Configure environment variables or Firebase functions config for DB credentials.
   - Locally add `.env` (see `server/.env.example`). For Cloud Functions use `firebase functions:config:set mysql.host="..." mysql.user="..." mysql.pass="..." mysql.name="..."`.
3. Install server deps: `cd server && npm ci` and install functions deps: `cd server/functions && npm ci`.

Running locally
1. Start MySQL and ensure tables are created.
2. Start API server: `cd server && npm run start` (defaults to port 8080).
3. The API endpoints (e.g., `GET /vehicles`) require a Firebase ID token in the `Authorization: Bearer <token>` header.

Example: curl with Firebase ID token
1. Get a Firebase ID token from the app or using the Firebase Admin SDK / client SDK (e.g., `await firebase.auth().currentUser.getIdToken()` in your app).
2. Call the API:

   ```bash
   curl -H "Authorization: Bearer <ID_TOKEN>" https://your-api-host/vehicles
   ```

Deploying the Cloud Function
1. `cd server/functions`
2. `firebase deploy --only functions:syncVehicle`

Security & Best Practices
- Store DB credentials in Secret Manager or use functions config (avoid committing secrets).
- Use least-privilege service accounts for Cloud Functions to access Cloud SQL if using Google Cloud SQL.
- Consider using a message queue (Pub/Sub) for guaranteed delivery, retries, and observable sync pipelines if scale or reliability is a concern.

Next steps
- Add pagination and filtering to the API.
- Add additional endpoints for bookings and user management.
- Add integration tests that exercise the sync function against a test MySQL instance.
