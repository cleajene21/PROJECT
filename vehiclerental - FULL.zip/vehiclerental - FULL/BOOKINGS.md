Booking feature

Summary
- Bookings are stored as subcollection `vehicles/{vehicleId}/bookings/{bookingId}`.
- Booking fields: `vehicleId`, `renterUid`, `vehicleOwner`, `startDate`, `endDate`, `status`, `createdAt`.
- Status values: `pending`, `approved`, `declined`, `cancelled`.

Client flows
- Renter requests a booking via `BookingForm` (stored with status `pending`).
- Vehicle owner sees pending bookings in `OwnerBookings` and may `approve` or `decline` them.
- Renter can cancel their pending booking via `MyBookings`.
- Notifications for booking requests and status changes are written to `notifications` collection by Cloud Functions `onBookingWrite`.

Security rules
- Only authenticated users can create bookings, and they must be the `renterUid` in the request.
- Owners (vehicle `createdBy`) may update status to `approved` or `declined`.
- Renters may cancel their booking (set status to `cancelled`).

Cloud Function
- `onBookingWrite` (functions/index.js) creates notification documents for owner when a booking is requested and for renter when booking status changes.

Testing
- Unit tests included in `firestore-tests/security.test.js` verify booking creation and approval rules.