Firestore Security Rules for Vehicle Rental

Summary
- File: `firestore.rules`
- Purpose: Enforce role-based access:
  - Admins: full access (read/write/delete) on `vehicles`, read/update/delete any `users/{uid}` and set roles
  - Users: read vehicles, create/update their own profile but cannot set/change `role`. Only roles allowed in the system are **'user'** and **'admin'`.

Bookings
- Bookings are located under `vehicles/{vehicleId}/bookings` and are writeable by authenticated renters (they must be `renterUid` in the booking). Vehicle owners (document `vehicles/{vehicleId}.createdBy`) can approve or decline bookings. Rules exist to prevent non-authorized users from updating the booking status.
  - Unauthenticated users: denied for writes; reads require authentication

Local testing (recommended)
1. Install Node.js and npm (https://nodejs.org/).
2. From project root:
   ```bash
   npm install
   npm run test:rules
   ```
3. Tests are in `firestore-tests/` and use `@firebase/rules-unit-testing` to validate the intended policy.

Deploying rules
1. Install & authenticate Firebase CLI: `npm install -g firebase-tools` and `firebase login`.
2. Initialize or update Firestore rules in your Firebase project: `firebase init firestore` and point to `firestore.rules`.
3. Deploy rules: `firebase deploy --only firestore:rules`.

Notes
- The test suite runs in an emulated test environment and seeds initial documents with the emulator bypass option to set admin roles.
- If you want, I can add a GitHub Actions workflow to run the rules tests on each PR or help you perform the deployment (you must provide Firebase CLI authentication or run the deploy yourself).

CI-based deploy (recommended)

You can automate rule deployment on merges to `main` using GitHub Actions. The repo includes a workflow at `.github/workflows/firestore-deploy.yml` which:

- Runs the rules tests on push and PRs.
- After tests pass on `main`, authenticates with a Google service account and deploys `firestore.rules`.

To configure the workflow:

1. Create a Google service account for your Firebase project with the minimum roles necessary (e.g., **Firebase Rules Admin** or **Firestore Admin**) and generate a JSON key.
2. In your repository settings, add these secrets:
   - `FIREBASE_SERVICE_ACCOUNT`: the **entire** JSON key contents from the service account.
   - `FIREBASE_PROJECT_ID`: your Firebase project id (e.g., `my-firebase-project`).
3. The workflow will authenticate using the service account and run:

   ```bash
   npx firebase deploy --only firestore:rules --project ${{ secrets.FIREBASE_PROJECT_ID }}
   ```

Security note: keep the service account key secure and grant the least privilege required. If you'd like, I can help create the service account JSON and add the example GitHub Secrets (you must add them to the repo settings yourself or provide the secret values via a secure channel).
