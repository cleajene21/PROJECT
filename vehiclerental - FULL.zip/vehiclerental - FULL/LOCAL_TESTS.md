Local integration & emulator testing

1) MySQL integration test (no Firestore emulator needed)
- Ensure MySQL is running and create the DB:
  - mysql -u root -p
  - CREATE DATABASE vehiclerental;
  - mysql -u root -p vehiclerental < sql/001_create_vehicles.sql
- Set env or use defaults (DB_HOST, DB_USER, DB_PASS, DB_NAME)
- From repo root:
  - cd server
  - npm ci
  - npm run test:integration

2) Firestore emulator + integration test
- Install firebase-tools: npm install -g firebase-tools
- Start emulator in project root:
  - firebase emulators:start --only firestore --project demo-test
- In another terminal set env and run:
  - cd server
  - npm ci
  - export FIRESTORE_EMULATOR_HOST=127.0.0.1:8080
  - export FIREBASE_PROJECT_ID=demo-test
  - npm run test:integration:emulator

Docker Compose helper
- Use `docker-compose.yml` at project root to start MySQL, Adminer (DB UI) and a container that runs the Firestore emulator:
  - Start services: `docker compose up -d`
  - Admin UI for DB: http://localhost:8081
  - Firestore emulator: http://localhost:8080

Run emulator with `emulators:exec`
- Recommended for CI/local: `firebase emulators:exec --project demo-test "cd server && npm ci && npm run test:integration:emulator"`

Notes
- The emulator test invokes the sync function directly with a simulated change; it expects MySQL to be available. Use Docker to run MySQL locally for convenience.
- If you want, I can add a docker-compose override to run everything in a single command and tear down after tests.