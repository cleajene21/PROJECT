const mysql = require('mysql2/promise');
const fs = require('fs');
const path = require('path');

// Simple retry helper for MySQL connectivity
async function waitForMysql(cfg, retries = 30, delay = 2000) {
  for (let i = 0; i < retries; i++) {
    try {
      const conn = await mysql.createConnection(cfg);
      await conn.end();
      return;
    } catch (e) {
      console.log(`MySQL not ready, retry ${i + 1}/${retries}...`);
      await new Promise((r) => setTimeout(r, delay));
    }
  }
  throw new Error('MySQL not available');
}

async function run() {
  const cfg = {
    host: process.env.DB_HOST || '127.0.0.1',
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASS || 'password',
    database: process.env.DB_NAME || 'vehiclerental',
    port: process.env.DB_PORT ? parseInt(process.env.DB_PORT, 10) : 3306,
  };

  console.log('Waiting for MySQL...');
  await waitForMysql(cfg);

  const conn = await mysql.createConnection(cfg);
  try {
    console.log('Applying schema...');
    const sql = fs.readFileSync(path.resolve(__dirname, '..', 'sql', '001_create_vehicles.sql'), 'utf8');
    // Simple split by semicolon - suits this migration file
    const parts = sql.split(';').map(s => s.trim()).filter(s => s.length > 0);
    for (const p of parts) {
      await conn.query(p);
    }

    // Clean up
    await conn.query('DELETE FROM vehicles');

    // Prepare a fake Firestore change and call the sync function directly
    process.env.DB_HOST = cfg.host;
    process.env.DB_USER = cfg.user;
    process.env.DB_PASS = cfg.password;
    process.env.DB_NAME = cfg.database;

    // require the function module
    const funcModule = require(path.resolve(__dirname, '..', 'functions', 'index.js'));

    const vehicleId = `test-${Date.now()}`;
    const afterData = { make: 'TestMake', model: 'TestModel', createdAt: { seconds: Math.floor(Date.now() / 1000) } };

    const change = {
      before: { exists: false },
      after: { exists: true, data: () => afterData }
    };
    const context = { params: { vehicleId } };

    console.log('Invoking syncVehicle...');
    await funcModule.syncVehicle(change, context);

    // Wait a moment for DB write
    await new Promise(r => setTimeout(r, 1000));

    const [rows] = await conn.query('SELECT * FROM vehicles WHERE id = ?', [vehicleId]);
    if (rows.length === 0) {
      console.error('Sync failed: vehicle not found in MySQL');
      process.exit(1);
    }
    const row = rows[0];
    console.log('Sync success, row:', row);
    process.exit(0);
  } catch (e) {
    console.error('Integration test failed:', e);
    process.exit(1);
  } finally {
    try { await conn.end(); } catch { }
  }
}

run();