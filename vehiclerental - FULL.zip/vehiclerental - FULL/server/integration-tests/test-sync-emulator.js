const admin = require('firebase-admin');
const mysql = require('mysql2/promise');
const fs = require('fs');
const path = require('path');

async function run() {
  // Require FIRESTORE_EMULATOR_HOST to be set for this test
  if (!process.env.FIRESTORE_EMULATOR_HOST) {
    console.error('FIRESTORE_EMULATOR_HOST must be set to run this test (e.g., localhost:8080)');
    process.exit(1);
  }

  // Initialize admin SDK to talk to emulator
  admin.initializeApp({ projectId: process.env.FIREBASE_PROJECT_ID || 'demo-test' });
  const db = admin.firestore();

  // Create a sample vehicle doc in emulator
  const vehicleRef = db.collection('vehicles').doc('emulator-v1');
  await vehicleRef.set({ make: 'EmuMake', model: 'EmuModel', createdAt: admin.firestore.FieldValue.serverTimestamp(), createdBy: 'owner-emu' });

  // Wire DB connection
  const cfg = {
    host: process.env.DB_HOST || '127.0.0.1',
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASS || 'password',
    database: process.env.DB_NAME || 'vehiclerental',
    port: process.env.DB_PORT ? parseInt(process.env.DB_PORT, 10) : 3306,
  };

  // Wait for MySQL
  for (let i = 0; i < 20; i++) {
    try {
      const conn = await mysql.createConnection(cfg);
      await conn.end();
      break;
    } catch (e) {
      console.log('Waiting for MySQL...');
      await new Promise(r => setTimeout(r, 1000));
      if (i === 19) { console.error('MySQL never became ready'); process.exit(1); }
    }
  }

  // Apply schema
  const conn = await mysql.createConnection(cfg);
  try {
    const sql = fs.readFileSync(path.resolve(__dirname, '..', 'sql', '001_create_vehicles.sql'), 'utf8');
    const parts = sql.split(';').map(s => s.trim()).filter(s => s.length > 0);
    for (const p of parts) { await conn.query(p); }
    await conn.query('DELETE FROM vehicles');

    // Now call the sync function manually (like the other test)
    const funcModule = require(path.resolve(__dirname, '..', 'functions', 'index.js'));

    const change = {
      before: { exists: false },
      after: { exists: true, data: () => ({ make: 'EmuMake', model: 'EmuModel', createdAt: { seconds: Math.floor(Date.now() / 1000) } }) }
    };
    const context = { params: { vehicleId: 'emulator-v1' } };

    await funcModule.syncVehicle(change, context);

    await new Promise(r => setTimeout(r, 1000));
    const [rows] = await conn.query('SELECT * FROM vehicles WHERE id = ?', ['emulator-v1']);
    if (rows.length === 0) {
      console.error('Sync failed: vehicle not present in MySQL');
      process.exit(1);
    }
    console.log('Emulator sync success:', rows[0]);
    process.exit(0);
  } catch (e) {
    console.error('Error in emulator test:', e);
    process.exit(1);
  } finally {
    try { await conn.end(); } catch {};
  }
}

run();