-- Create vehicles table (expanded schema)
CREATE TABLE IF NOT EXISTS vehicles (
  id VARCHAR(128) PRIMARY KEY,
  make VARCHAR(255) NULL,
  model VARCHAR(255) NULL,
  year INT NULL,
  seats INT NULL,
  price_per_day DECIMAL(10,2) NULL,
  is_available TINYINT(1) DEFAULT 1,
  description TEXT NULL,
  createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
  updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Optional users table for role cache
CREATE TABLE IF NOT EXISTS users (
  id VARCHAR(128) PRIMARY KEY,
  email VARCHAR(255),
  displayName VARCHAR(255),
  role VARCHAR(50) DEFAULT 'user'
);
