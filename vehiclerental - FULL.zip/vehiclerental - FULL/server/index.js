require('dotenv').config();
const express = require('express');
const cors = require('cors');
const admin = require('firebase-admin');
const pool = require('./db');

// Initialize Firebase Admin SDK
if (process.env.FIREBASE_SERVICE_ACCOUNT_JSON) {
  admin.initializeApp({ credential: admin.credential.cert(JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT_JSON)) });
} else {
  admin.initializeApp();
}

const app = express();
app.use(cors());
app.use(express.json());

// Middleware to verify Firebase ID token
async function verifyToken(req, res, next) {
  const auth = req.headers.authorization;
  if (!auth || !auth.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Missing or invalid Authorization header' });
  }
  const idToken = auth.split('Bearer ')[1];
  try {
    const decoded = await admin.auth().verifyIdToken(idToken);
    req.user = decoded;
    next();
  } catch (e) {
    return res.status(401).json({ error: 'Unauthorized', details: e.message });
  }
}

// Admin check middleware (reads Firestore user profile)
async function requireAdmin(req, res, next) {
  const uid = req.user?.uid;
  if (!uid) return res.status(403).json({ error: 'Forbidden' });
  const doc = await admin.firestore().doc(`users/${uid}`).get();
  if (!doc.exists || doc.data()?.role !== 'admin') return res.status(403).json({ error: 'Admin required' });
  next();
}

// Public: read vehicles list (from MySQL)
app.get('/vehicles', verifyToken, async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM vehicles ORDER BY createdAt DESC');
    res.json(rows);
  } catch (e) {
    res.status(500).json({ error: 'Database error', details: e.message });
  }
});

// Admin only: refresh sync or run manual operations
app.post('/sync/vehicles', verifyToken, requireAdmin, async (req, res) => {
  // Placeholder: in future run a full sync job
  res.json({ status: 'not_implemented' });
});

const PORT = process.env.PORT || 8080;
app.listen(PORT, () => console.log(`Vehiclerental API listening on ${PORT}`));
