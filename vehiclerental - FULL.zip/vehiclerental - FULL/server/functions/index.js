const functions = require('firebase-functions');
const admin = require('firebase-admin');
const mysql = require('mysql2/promise');

admin.initializeApp();

async function getDbConnection() {
  // Use environment variables (set via `firebase functions:config:set` or secrets)
  const cfg = functions.config().mysql || {};
  const conn = await mysql.createConnection({
    host: cfg.host || process.env.DB_HOST,
    user: cfg.user || process.env.DB_USER,
    password: cfg.pass || process.env.DB_PASS,
    database: cfg.name || process.env.DB_NAME,
  });
  return conn;
}

exports.syncVehicle = functions.firestore.document('vehicles/{vehicleId}').onWrite(async (change, context) => {
  const vehicleId = context.params.vehicleId;
  const before = change.before.exists ? change.before.data() : null;
  const after = change.after.exists ? change.after.data() : null;

  const conn = await getDbConnection();
  try {
    if (!before && after) {
      // Create
      const createdAt = after['createdAt'] ? new Date(after['createdAt'].seconds * 1000) : new Date();
      await conn.execute(
        'INSERT INTO vehicles (id, make, model, createdAt) VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE make=VALUES(make), model=VALUES(model), updatedAt=NOW()',
        [vehicleId, after['make'] || null, after['model'] || null, createdAt]
      );
    } else if (before && after) {
      await conn.execute('UPDATE vehicles SET make=?, model=?, updatedAt=NOW() WHERE id=?', [after['make'] || null, after['model'] || null, vehicleId]);
    } else if (before && !after) {
      await conn.execute('DELETE FROM vehicles WHERE id=?', [vehicleId]);
    }
  } finally {
    await conn.end();
  }
});

// Create notification documents on booking creation or status change
exports.onBookingWrite = functions.firestore.document('vehicles/{vehicleId}/bookings/{bookingId}').onWrite(async (change, context) => {
  const booking = change.after.exists ? change.after.data() : change.before.data();
  if (!booking) return;

  const status = booking.status || 'pending';
  const renter = booking.renterUid;
  const owner = booking.vehicleOwner;
  const vehicleId = context.params.vehicleId;
  const bookingId = context.params.bookingId;

  const db = admin.firestore();

  // create a notification for the owner when new booking requested
  if (!change.before.exists && change.after.exists) {
    await db.collection('notifications').add({
      to: owner,
      type: 'booking_requested',
      bookingId,
      vehicleId,
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
      read: false,
    });
  }

  // create a notification for the renter when status changes
  if (change.before.exists && change.after.exists && change.before.data().status !== change.after.data().status) {
    await db.collection('notifications').add({
      to: renter,
      type: 'booking_status_changed',
      bookingId,
      vehicleId,
      status,
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
      read: false,
    });
  }
});
