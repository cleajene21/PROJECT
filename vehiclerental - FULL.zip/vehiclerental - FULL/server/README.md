Vehiclerental Backend (MySQL + Sync)

Overview
- Express API that serves vehicle data from MySQL.
- Firestore -> MySQL sync Cloud Function (`functions/syncVehicle`) listens to changes in `vehicles/{id}` and mirrors to MySQL.

Quick start (local API)
1. Copy `.env.example` to `.env` and configure DB and Firebase admin credentials.
2. Run migrations: `mysql -u user -p vehiclerental < sql/001_create_vehicles.sql`.
3. Install dependencies: `npm ci` and `cd functions && npm ci`.
4. Start API: `npm run start`.

Deploy Cloud Function
1. Set firebase functions config for MySQL credentials (recommended) or use environment vars:
   - `firebase functions:config:set mysql.host="..." mysql.user="..." mysql.pass="..." mysql.name="..."`
2. Deploy functions: `cd functions && firebase deploy --only functions:syncVehicle`

CI / Automated deploy
- A GitHub Actions workflow `.github/workflows/functions-deploy.yml` is included to deploy the `syncVehicle` function on merges to `main`.
- Required repository secrets (Settings → Secrets):
  - `FIREBASE_SERVICE_ACCOUNT`: The JSON service account key (used for gcloud auth).
  - `FIREBASE_PROJECT_ID`: Your Firebase / GCP project id.

Security note
- Use Secret Manager or Firebase functions config to store DB credentials securely and not commit them to source control.
- The API authenticates callers using Firebase ID tokens (checks `Authorization: Bearer <token>` header).

Next steps
- Add more endpoints for user and booking operations, with proper role checks.
- Consider a queue to handle retries if the MySQL server is temporarily unavailable.
- Integration tests are provided and run in CI (`.github/workflows/ci-and-deploy.yml`) to validate Firestore→MySQL sync logic and a Firestore emulator test. Local commands are shown below.