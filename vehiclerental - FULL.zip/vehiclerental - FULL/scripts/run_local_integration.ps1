# Run local integration tests (PowerShell) - assumes Docker and firebase-tools are installed
# 1) Start docker-compose (MySQL + emulator)
#    docker compose up -d
# 2) Wait for MySQL to be ready (healthcheck)
# 3) Run MySQL integration test
#    cd server
#    npm ci
#    npm run test:integration
# 4) Run emulator-based integration test
#    firebase emulators:exec --only firestore --project demo-test "cd server && npm ci && npm run test:integration:emulator"

param()

Write-Host "Starting local integration helper..."
Write-Host "1) Bringing up services via docker-compose..."
docker compose up -d

Write-Host "Please wait for MySQL to become healthy (use 'docker compose ps' to check)."
Write-Host "Once MySQL is ready, run the tests with:"
Write-Host "  cd server; npm ci; npm run test:integration"
Write-Host "Then run the emulator test with:"
Write-Host "  firebase emulators:exec --only firestore --project demo-test \"cd server && npm ci && npm run test:integration:emulator\""
Write-Host "When done, tear down with: docker compose down -v"
