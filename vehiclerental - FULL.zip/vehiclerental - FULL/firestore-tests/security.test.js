const { initializeTestEnvironment, assertSucceeds, assertFails } = require('@firebase/rules-unit-testing');
const fs = require('fs');

const PROJECT_ID = 'vehiclerental-test';
let testEnv;

before(async () => {
  const rules = fs.readFileSync('..\/firestore.rules', 'utf8');
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: { rules }
  });
});

after(async () => {
  await testEnv.cleanup();
});

describe('Firestore rules - vehicles & users', () => {
  it('admin can create a vehicle', async () => {
    // seed admin user document with security rules disabled
    await testEnv.withSecurityRulesDisabled(async (context) => {
      const admin = context.firestore().doc('users/admin1');
      await admin.set({ role: 'admin', email: 'admin@example.com' });
    });

    const adminCtx = testEnv.authenticatedContext('admin1');
    const adminDb = adminCtx.firestore();

    await assertSucceeds(adminDb.collection('vehicles').add({ make: 'Ford', model: 'Focus' }));
  });

  it('regular user cannot create a vehicle', async () => {
    const userCtx = testEnv.authenticatedContext('user1');
    const userDb = userCtx.firestore();

    await assertFails(userDb.collection('vehicles').add({ make: 'Honda', model: 'Civic' }));
  });

  it('authenticated user can read vehicles', async () => {
    const userCtx = testEnv.authenticatedContext('user2');
    const userDb = userCtx.firestore();

    await testEnv.withSecurityRulesDisabled(async (ctx) => {
      await ctx.firestore().collection('vehicles').add({ make: 'Tesla', model: 'Model3' });
    });

    await assertSucceeds(userDb.collection('vehicles').get());
  });

  it('user can create own profile but not set role to admin', async () => {
    const userCtx = testEnv.authenticatedContext('user3');
    const userDb = userCtx.firestore();

    // creating a profile with default role (user) succeeds
    await assertSucceeds(userDb.doc('users/user3').set({ email: 'u3@example.com', role: 'user' }));

    // attempting to set role to admin should fail
    await assertFails(userDb.doc('users/user3').set({ email: 'u3@example.com', role: 'admin' }));
  });

  it('admin can set user role to admin but not to arbitrary values', async () => {
    // seed a user profile
    await testEnv.withSecurityRulesDisabled(async (context) => {
      await context.firestore().doc('users/user5').set({ email: 'u5@example.com', role: 'user' });
    });

    const adminCtx = testEnv.authenticatedContext('admin1');
    const adminDb = adminCtx.firestore();

    // admin can promote to admin
    await assertSucceeds(adminDb.doc('users/user5').update({ role: 'admin' }));

    // admin cannot set an unknown role (e.g., 'owner')
    await assertFails(adminDb.doc('users/user5').update({ role: 'owner' }));
  });

  it('renter can create booking and owner can approve', async () => {
    // seed vehicle owned by owner1
    await testEnv.withSecurityRulesDisabled(async (context) => {
      await context.firestore().doc('vehicles/v1').set({ make: 'Test', model: 'Car', createdBy: 'owner1' });
    });

    const renterCtx = testEnv.authenticatedContext('renter1');
    const renterDb = renterCtx.firestore();

    // renter can create a booking under vehicle's bookings subcollection
    await assertSucceeds(renterDb.collection('vehicles').doc('v1').collection('bookings').add({ vehicleId: 'v1', renterUid: 'renter1', vehicleOwner: 'owner1', status: 'pending' }));

    // owner can approve
    const ownerCtx = testEnv.authenticatedContext('owner1');
    const ownerDb = ownerCtx.firestore();

    // seed a booking doc to update
    let bookingId;
    await testEnv.withSecurityRulesDisabled(async (ctx) => {
      const doc = await ctx.firestore().collection('vehicles').doc('v1').collection('bookings').add({ vehicleId: 'v1', renterUid: 'renter1', vehicleOwner: 'owner1', status: 'pending' });
      bookingId = doc.id;
    });

    await assertSucceeds(ownerDb.collection('vehicles').doc('v1').collection('bookings').doc(bookingId).update({ status: 'approved' }));

    // a random other user cannot approve
    const otherCtx = testEnv.authenticatedContext('userX');
    const otherDb = otherCtx.firestore();
    await assertFails(otherDb.collection('vehicles').doc('v1').collection('bookings').doc(bookingId).update({ status: 'approved' }));
  });

  it('user cannot change their role via update', async () => {
    // seed a user profile
    await testEnv.withSecurityRulesDisabled(async (context) => {
      await context.firestore().doc('users/user4').set({ email: 'u4@example.com', role: 'user' });
    });

    const userCtx = testEnv.authenticatedContext('user4');
    const userDb = userCtx.firestore();

    // attempt to change role should fail
    await assertFails(userDb.doc('users/user4').update({ role: 'admin' }));

    // updating non-role fields should succeed
    await assertSucceeds(userDb.doc('users/user4').update({ displayName: 'User Four' }));
  });
});